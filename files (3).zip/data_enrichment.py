"""
DATA ENRICHMENT SYSTEM
Gathers additional property and homeowner data to improve lead qualification
"""

import requests
from typing import Dict, Optional
import os
from datetime import datetime
import json


class PropertyDataEnricher:
    """
    Enriches property data from multiple sources
    Essential for accurate lead scoring
    """
    
    def __init__(
        self,
        attom_api_key: Optional[str] = None,
        meliss

a_api_key: Optional[str] = None,
        smarty_api_key: Optional[str] = None
    ):
        """
        Initialize with API keys for data providers
        
        Data Sources:
        - Attom Data: Property values, sales history, ownership
        - Melissa Data: Address validation, demographics
        - SmartyStreets: Address verification
        - Census Data: Neighborhood demographics (free)
        """
        
        self.attom_api_key = attom_api_key or os.getenv('ATTOM_API_KEY')
        self.melissa_api_key = melissa_api_key or os.getenv('MELISSA_API_KEY')
        self.smarty_api_key = smarty_api_key or os.getenv('SMARTY_API_KEY')
    
    def enrich_property(self, address: str, city: str, state: str, zip_code: str) -> Dict:
        """
        Comprehensive property enrichment
        
        Returns enrichment data including:
        - Property value
        - Household income (estimated)
        - Owner occupancy status
        - Years at address
        - Recent sales history
        - Neighborhood quality
        - Insurance claim history
        - Financial risk indicators
        """
        
        enrichment = {
            'enriched_at': datetime.now().isoformat(),
            'data_sources': [],
            'confidence_score': 0
        }
        
        # 1. Property Value & Ownership (Attom Data)
        if self.attom_api_key:
            attom_data = self._fetch_attom_data(address, city, state, zip_code)
            if attom_data:
                enrichment.update(attom_data)
                enrichment['data_sources'].append('Attom')
        
        # 2. Address Validation & Demographics (Melissa Data)
        if self.melissa_api_key:
            melissa_data = self._fetch_melissa_data(address, city, state, zip_code)
            if melissa_data:
                enrichment.update(melissa_data)
                enrichment['data_sources'].append('Melissa')
        
        # 3. Census Data (Free - neighborhood demographics)
        census_data = self._fetch_census_data(zip_code)
        if census_data:
            enrichment.update(census_data)
            enrichment['data_sources'].append('Census')
        
        # 4. Calculate confidence score based on data completeness
        enrichment['confidence_score'] = self._calculate_enrichment_confidence(enrichment)
        
        return enrichment
    
    def _fetch_attom_data(self, address: str, city: str, state: str, zip_code: str) -> Optional[Dict]:
        """
        Fetch property data from Attom Data API
        
        Provides:
        - Current property value (AVM)
        - Last sale date & price
        - Owner name & occupancy
        - Year built
        - Square footage
        - Lot size
        - Property type
        """
        
        if not self.attom_api_key:
            return None
        
        try:
            # Attom Property API endpoint
            url = "https://api.gateway.attomdata.com/propertyapi/v1.0.0/property/address"
            
            headers = {
                'apikey': self.attom_api_key,
                'accept': 'application/json'
            }
            
            params = {
                'address1': address,
                'address2': f"{city}, {state} {zip_code}"
            }
            
            response = requests.get(url, headers=headers, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                
                # Extract relevant fields
                property_info = data.get('property', [{}])[0]
                
                return {
                    'property_value': property_info.get('assessment', {}).get('market', {}).get('mktttlvalue', 0),
                    'last_sale_date': property_info.get('sale', {}).get('saleTransDate', None),
                    'last_sale_price': property_info.get('sale', {}).get('saleAmt', 0),
                    'owner_occupied': property_info.get('owner', {}).get('ownerOccupied', 'Unknown') == 'Yes',
                    'year_built': property_info.get('summary', {}).get('yearbuilt', None),
                    'square_footage': property_info.get('building', {}).get('size', {}).get('bldgsize', 0),
                    'lot_size': property_info.get('lot', {}).get('lotsize1', 0),
                    'property_type': property_info.get('summary', {}).get('proptype', 'Unknown'),
                    'bedroom_count': property_info.get('building', {}).get('rooms', {}).get('beds', 0),
                    'bathroom_count': property_info.get('building', {}).get('rooms', {}).get('bathstotal', 0),
                }
            
        except Exception as e:
            print(f"Error fetching Attom data: {e}")
        
        return None
    
    def _fetch_melissa_data(self, address: str, city: str, state: str, zip_code: str) -> Optional[Dict]:
        """
        Fetch demographics from Melissa Data
        
        Provides:
        - Address validation/standardization
        - Household income (estimated)
        - Length of residence
        - Home value (alternative estimate)
        - Owner vs renter
        """
        
        if not self.melissa_api_key:
            return None
        
        try:
            # Melissa Property API
            url = "https://property.melissadata.net/v4/WEB/LookupProperty"
            
            params = {
                'id': self.melissa_api_key,
                'ff': address,
                'city': city,
                'state': state,
                'zip': zip_code,
                'format': 'json'
            }
            
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                records = data.get('Records', [])
                
                if records:
                    record = records[0]
                    
                    return {
                        'household_income': int(record.get('MedianHouseholdIncome', 0)),
                        'years_at_address': int(record.get('LengthOfResidence', 0)),
                        'home_value_estimate': int(record.get('MarketValue', 0)),
                        'owner_vs_renter': record.get('OwnerRenter', 'Unknown'),
                    }
        
        except Exception as e:
            print(f"Error fetching Melissa data: {e}")
        
        return None
    
    def _fetch_census_data(self, zip_code: str) -> Optional[Dict]:
        """
        Fetch neighborhood demographics from US Census (free)
        
        Provides:
        - Median household income (zip level)
        - Population density
        - Home value statistics
        - Age demographics
        """
        
        try:
            # Census API - no key required for basic queries
            url = f"https://api.census.gov/data/2021/acs/acs5"
            
            params = {
                'get': 'B19013_001E,B25077_001E,B01002_001E,B25001_001E',  # Income, home value, age, housing units
                'for': f'zip code tabulation area:{zip_code}'
            }
            
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                
                if len(data) > 1:
                    values = data[1]
                    
                    return {
                        'median_household_income_zip': int(values[0]) if values[0] and values[0] != '-666666666' else 0,
                        'median_home_value_zip': int(values[1]) if values[1] and values[1] != '-666666666' else 0,
                        'median_age_zip': float(values[2]) if values[2] and values[2] != '-666666666' else 0,
                        'housing_units_zip': int(values[3]) if values[3] else 0,
                        'neighborhood_quality': self._estimate_neighborhood_quality(values)
                    }
        
        except Exception as e:
            print(f"Error fetching Census data: {e}")
        
        return None
    
    def _estimate_neighborhood_quality(self, census_values: list) -> float:
        """
        Estimate neighborhood quality score (0-100) based on census data
        """
        
        try:
            median_income = int(census_values[0]) if census_values[0] and census_values[0] != '-666666666' else 0
            median_home_value = int(census_values[1]) if census_values[1] and census_values[1] != '-666666666' else 0
            
            # Simple scoring based on income and home value
            income_score = min(100, (median_income / 1000))  # $100K = 100 points
            value_score = min(100, (median_home_value / 5000))  # $500K = 100 points
            
            # Average the two
            quality_score = (income_score + value_score) / 2
            
            return quality_score
        
        except:
            return 50  # Default neutral score
    
    def _calculate_enrichment_confidence(self, enrichment: Dict) -> float:
        """
        Calculate confidence score based on data completeness
        """
        
        # Key fields to check
        important_fields = [
            'property_value',
            'household_income',
            'owner_occupied',
            'years_at_address',
            'year_built',
            'square_footage'
        ]
        
        present_count = sum(1 for field in important_fields if enrichment.get(field))
        
        confidence = (present_count / len(important_fields)) * 100
        
        # Bonus for multiple data sources
        source_count = len(enrichment.get('data_sources', []))
        if source_count >= 2:
            confidence = min(100, confidence + 10)
        
        return confidence


class ForecastInsightEnricher:
    """
    Additional enrichment from specialized data providers
    """
    
    def __init__(self):
        pass
    
    def enrich_with_weather_risk(self, latitude: float, longitude: float, zip_code: str) -> Dict:
        """
        Add weather risk data (hail zones, hurricane zones, etc.)
        This increases urgency for properties in high-risk areas
        """
        
        # Hail risk zones (approximate - would use real API)
        hail_risk_states = ['TX', 'OK', 'KS', 'NE', 'CO']
        hail_risk_zips = ['75201', '75202', '73301']  # Example high-risk zips
        
        # Hurricane risk (coastal areas)
        hurricane_risk_states = ['FL', 'TX', 'LA', 'MS', 'AL', 'GA', 'SC', 'NC']
        
        return {
            'hail_risk_zone': zip_code in hail_risk_zips,
            'hurricane_risk_zone': False,  # Would check coastal proximity
            'severe_weather_frequency': 'high',  # Would use historical data
            'insurance_claim_likelihood': 0.35  # 35% likelihood based on location
        }
    
    def enrich_with_mortgage_data(self, address: str) -> Dict:
        """
        Check mortgage status (affects ability to finance roof)
        """
        
        # This would connect to mortgage data providers
        # For now, return placeholder
        
        return {
            'has_mortgage': True,
            'estimated_equity': 150000,
            'mortgage_age_years': 8,
            'refinance_recent': False
        }


# Example usage
if __name__ == "__main__":
    # Initialize enricher
    enricher = PropertyDataEnricher()
    
    # Enrich property
    enrichment = enricher.enrich_property(
        address="123 Main Street",
        city="Dallas",
        state="TX",
        zip_code="75201"
    )
    
    print("\n" + "="*60)
    print("PROPERTY ENRICHMENT RESULTS")
    print("="*60)
    
    print(f"\nData Sources Used: {', '.join(enrichment.get('data_sources', []))}")
    print(f"Confidence Score: {enrichment.get('confidence_score', 0):.0f}%")
    
    print(f"\nProperty Information:")
    if 'property_value' in enrichment:
        print(f"  Property Value: ${enrichment['property_value']:,}")
    if 'square_footage' in enrichment:
        print(f"  Square Footage: {enrichment['square_footage']:,}")
    if 'year_built' in enrichment:
        print(f"  Year Built: {enrichment['year_built']}")
    
    print(f"\nHomeowner Information:")
    if 'household_income' in enrichment:
        print(f"  Household Income: ${enrichment['household_income']:,}")
    if 'years_at_address' in enrichment:
        print(f"  Years at Address: {enrichment['years_at_address']}")
    if 'owner_occupied' in enrichment:
        print(f"  Owner Occupied: {enrichment['owner_occupied']}")
    
    print(f"\nNeighborhood Data:")
    if 'median_household_income_zip' in enrichment:
        print(f"  Median Income (ZIP): ${enrichment['median_household_income_zip']:,}")
    if 'neighborhood_quality' in enrichment:
        print(f"  Neighborhood Quality: {enrichment['neighborhood_quality']:.0f}/100")
