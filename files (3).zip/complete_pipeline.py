"""
COMPLETE ROOF ANALYSIS PIPELINE
Integrates image enhancement, Claude Vision analysis, and annotation
"""

import cv2
import numpy as np
from typing import Dict, Optional
import os
from datetime import datetime
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.units import inch
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
from reportlab.lib.colors import HexColor
from reportlab.platypus import Table, TableStyle
import io
from PIL import Image

from image_enhancer import RoofImageEnhancer
from roof_annotator import RoofDamageAnnotator


class CompleteRoofAnalysisPipeline:
    """
    End-to-end pipeline for roof damage detection
    """
    
    def __init__(self, anthropic_api_key: str = None):
        """Initialize pipeline components"""
        self.enhancer = RoofImageEnhancer()
        self.annotator = RoofDamageAnnotator(anthropic_api_key)
    
    def analyze_roof(
        self,
        image_data: bytes,
        property_data: Dict,
        enhancement_level: str = "aggressive",
        output_dir: str = "./output"
    ) -> Dict:
        """
        Complete analysis pipeline
        
        Args:
            image_data: Raw satellite image bytes
            property_data: Property metadata
            enhancement_level: "light", "moderate", or "aggressive"
            output_dir: Where to save results
            
        Returns:
            Complete analysis results with file paths
        """
        
        # Create output directory
        os.makedirs(output_dir, exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        address_safe = property_data.get('address', 'unknown').replace(' ', '_').replace(',', '')
        base_filename = f"{address_safe}_{timestamp}"
        
        print("🚀 Starting Complete Roof Analysis Pipeline...")
        print(f"📍 Property: {property_data.get('address', 'Unknown')}")
        print(f"📅 Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        # STAGE 1: Image Enhancement
        print("\n🔬 STAGE 1: Enhancing satellite imagery...")
        enhancement_result = self.enhancer.enhance_image(image_data, enhancement_level)
        
        print(f"  ✓ Applied {len(enhancement_result['enhancement_log'])} enhancement stages:")
        for stage in enhancement_result['enhancement_log']:
            print(f"    • {stage}")
        
        # Save enhanced image
        enhanced_path = os.path.join(output_dir, f"{base_filename}_enhanced.jpg")
        cv2.imwrite(enhanced_path, enhancement_result['enhanced_final'])
        print(f"  ✓ Saved enhanced image: {enhanced_path}")
        
        # Save comparison
        comparison = self.enhancer.compare_before_after(
            enhancement_result['original'],
            enhancement_result['enhanced_final']
        )
        comparison_path = os.path.join(output_dir, f"{base_filename}_comparison.jpg")
        cv2.imwrite(comparison_path, comparison)
        print(f"  ✓ Saved before/after comparison: {comparison_path}")
        
        # Save specialized views
        specialized_paths = {}
        for view_name, view_img in enhancement_result['specialized_views'].items():
            view_path = os.path.join(output_dir, f"{base_filename}_view_{view_name}.jpg")
            cv2.imwrite(view_path, view_img)
            specialized_paths[view_name] = view_path
        print(f"  ✓ Saved {len(specialized_paths)} specialized views")
        
        # STAGE 2: AI Analysis with Claude Vision
        print("\n🤖 STAGE 2: Analyzing with Claude Vision AI...")
        annotation_result = self.annotator.analyze_and_annotate(
            enhancement_result['enhanced_base64'],
            property_data,
            include_specialized_views=True
        )
        
        print(f"  ✓ Analysis complete!")
        print(f"    • Condition Score: {annotation_result['analysis']['condition_score']}/100")
        print(f"    • Issues Found: {len(annotation_result['damage_annotations'])}")
        print(f"    • Urgency: {annotation_result['analysis']['replacement_urgency']}")
        print(f"    • Lead Priority: {annotation_result['analysis']['lead_quality']['priority']}")
        
        # Print damage breakdown
        if annotation_result['damage_annotations']:
            print(f"\n  📋 Damage Breakdown:")
            for damage in annotation_result['damage_annotations']:
                severity_emoji = {
                    'CRITICAL': '🔴',
                    'URGENT': '🟠',
                    'MODERATE': '🟡',
                    'MINOR': '🟢'
                }
                emoji = severity_emoji.get(damage['severity'], '⚪')
                print(f"    {emoji} {damage['type'].replace('_', ' ').title()}: "
                      f"{damage['coverage']:.1f}% coverage - {damage['location']}")
        
        # STAGE 3: Create Annotated Images
        print("\n🎨 STAGE 3: Creating annotated visualizations...")
        
        # Save main annotated image
        annotated_path = os.path.join(output_dir, f"{base_filename}_annotated.jpg")
        self.annotator.save_annotated_image(
            annotation_result['annotated_image'],
            annotated_path
        )
        print(f"  ✓ Saved annotated image: {annotated_path}")
        
        # Save image with legend
        legend_path = os.path.join(output_dir, f"{base_filename}_annotated_legend.jpg")
        self.annotator.save_annotated_image(
            annotation_result['image_with_legend'],
            legend_path
        )
        print(f"  ✓ Saved image with legend: {legend_path}")
        
        # Save damage-specific overlays
        overlay_paths = {}
        for damage_type, overlay_img in annotation_result['specialized_overlays'].items():
            overlay_path = os.path.join(output_dir, f"{base_filename}_overlay_{damage_type}.jpg")
            self.annotator.save_annotated_image(overlay_img, overlay_path)
            overlay_paths[damage_type] = overlay_path
        print(f"  ✓ Saved {len(overlay_paths)} damage-specific overlays")
        
        # STAGE 4: Generate PDF Report
        print("\n📄 STAGE 4: Generating professional PDF report...")
        report_path = os.path.join(output_dir, f"{base_filename}_report.pdf")
        
        self._generate_pdf_report(
            report_path,
            property_data,
            annotation_result,
            {
                'enhanced': enhanced_path,
                'annotated': legend_path,
                'comparison': comparison_path
            }
        )
        print(f"  ✓ Saved PDF report: {report_path}")
        
        # STAGE 5: Create Summary JSON
        print("\n💾 STAGE 5: Saving analysis data...")
        import json
        
        summary_data = {
            'property': property_data,
            'analysis_date': datetime.now().isoformat(),
            'analysis': annotation_result['analysis'],
            'damage_annotations': annotation_result['damage_annotations'],
            'summary_cards': annotation_result['summary_cards'],
            'files': {
                'enhanced_image': enhanced_path,
                'annotated_image': annotated_path,
                'legend_image': legend_path,
                'comparison_image': comparison_path,
                'pdf_report': report_path,
                'specialized_views': specialized_paths,
                'damage_overlays': overlay_paths
            }
        }
        
        json_path = os.path.join(output_dir, f"{base_filename}_data.json")
        with open(json_path, 'w') as f:
            json.dump(summary_data, f, indent=2)
        print(f"  ✓ Saved analysis data: {json_path}")
        
        print("\n✅ COMPLETE! Analysis pipeline finished successfully.")
        print(f"\n📊 FINAL SUMMARY:")
        print(f"  • Total Issues: {annotation_result['summary_cards']['total_issues']}")
        print(f"  • Priority Score: {annotation_result['summary_cards']['priority_score']}")
        print(f"  • Estimated Remaining Life: {annotation_result['summary_cards']['remaining_life']} years")
        print(f"  • Lead Quality: {annotation_result['summary_cards']['lead_quality']['priority']}")
        print(f"\n📁 All files saved to: {output_dir}")
        
        return summary_data
    
    def _generate_pdf_report(
        self,
        output_path: str,
        property_data: Dict,
        analysis_result: Dict,
        image_paths: Dict
    ):
        """Generate professional PDF report"""
        
        c = canvas.Canvas(output_path, pagesize=letter)
        width, height = letter
        
        # Colors
        primary_color = HexColor('#1e40af')
        danger_color = HexColor('#dc2626')
        warning_color = HexColor('#f59e0b')
        success_color = HexColor('#10b981')
        
        # PAGE 1: Cover & Summary
        # Header
        c.setFillColor(primary_color)
        c.rect(0, height - 120, width, 120, fill=True, stroke=False)
        
        c.setFillColor(HexColor('#ffffff'))
        c.setFont("Helvetica-Bold", 32)
        c.drawString(50, height - 70, "Aerial Roof Damage Assessment")
        
        c.setFont("Helvetica", 14)
        c.drawString(50, height - 95, f"Generated: {datetime.now().strftime('%B %d, %Y')}")
        
        # Property Information Box
        c.setFillColor(HexColor('#000000'))
        c.setFont("Helvetica-Bold", 16)
        c.drawString(50, height - 150, "Property Information")
        
        c.setFont("Helvetica", 11)
        y_pos = height - 175
        
        info_items = [
            ("Address:", property_data.get('address', 'N/A')),
            ("Year Built:", str(property_data.get('year_built', 'N/A'))),
            ("Roof Age:", f"{property_data.get('roof_age_years', 'N/A')} years"),
            ("Property Type:", property_data.get('property_type', 'N/A'))
        ]
        
        for label, value in info_items:
            c.setFont("Helvetica-Bold", 11)
            c.drawString(50, y_pos, label)
            c.setFont("Helvetica", 11)
            c.drawString(150, y_pos, value)
            y_pos -= 20
        
        # Analysis Summary Box
        y_pos -= 20
        c.setFont("Helvetica-Bold", 16)
        c.drawString(50, y_pos, "Analysis Summary")
        y_pos -= 25
        
        # Condition Score (Large)
        condition_score = analysis_result['analysis']['condition_score']
        
        # Determine color based on score
        if condition_score >= 75:
            score_color = success_color
            score_label = "Good Condition"
        elif condition_score >= 50:
            score_color = warning_color
            score_label = "Moderate Wear"
        elif condition_score >= 25:
            score_color = danger_color
            score_label = "Significant Damage"
        else:
            score_color = danger_color
            score_label = "Critical Condition"
        
        # Draw score circle
        c.setFillColor(score_color)
        c.circle(120, y_pos - 40, 50, fill=True, stroke=False)
        
        c.setFillColor(HexColor('#ffffff'))
        c.setFont("Helvetica-Bold", 32)
        c.drawCentredString(120, y_pos - 50, str(condition_score))
        c.setFont("Helvetica", 10)
        c.drawCentredString(120, y_pos - 70, "/100")
        
        # Score label
        c.setFillColor(HexColor('#000000'))
        c.setFont("Helvetica-Bold", 12)
        c.drawString(200, y_pos - 40, score_label)
        
        # Key Metrics
        c.setFont("Helvetica", 11)
        y_metric = y_pos - 55
        
        metrics = [
            ("Replacement Urgency:", analysis_result['analysis']['replacement_urgency']),
            ("Estimated Life Remaining:", 
             f"{analysis_result['analysis'].get('estimated_remaining_life_years', 'N/A')} years"),
            ("Lead Priority:", analysis_result['analysis']['lead_quality']['priority']),
            ("Total Issues Found:", str(len(analysis_result['damage_annotations'])))
        ]
        
        for label, value in metrics:
            c.setFont("Helvetica-Bold", 11)
            c.drawString(200, y_metric, label)
            c.setFont("Helvetica", 11)
            c.drawString(380, y_metric, str(value))
            y_metric -= 18
        
        # Severity Breakdown Table
        y_pos = y_metric - 30
        c.setFont("Helvetica-Bold", 14)
        c.drawString(50, y_pos, "Severity Breakdown")
        y_pos -= 20
        
        severity_data = [
            ['Severity Level', 'Count', 'Status'],
        ]
        
        severity_counts = analysis_result['summary_cards']['severity_breakdown']
        severity_colors_map = {
            'CRITICAL': danger_color,
            'URGENT': warning_color,
            'MODERATE': HexColor('#3b82f6'),
            'MINOR': success_color
        }
        
        for severity in ['CRITICAL', 'URGENT', 'MODERATE', 'MINOR']:
            count = severity_counts.get(severity, 0)
            severity_data.append([severity, str(count), '●'])
        
        table = Table(severity_data, colWidths=[2*inch, 1*inch, 0.5*inch])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), primary_color),
            ('TEXTCOLOR', (0, 0), (-1, 0), HexColor('#ffffff')),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('GRID', (0, 0), (-1, -1), 1, HexColor('#cccccc')),
        ]))
        
        table.wrapOn(c, width, height)
        table.drawOn(c, 50, y_pos - 100)
        
        # Homeowner Summary
        y_pos -= 150
        c.setFont("Helvetica-Bold", 14)
        c.drawString(50, y_pos, "Key Findings for Homeowner")
        y_pos -= 20
        
        c.setFont("Helvetica", 10)
        for summary_point in analysis_result['analysis'].get('homeowner_summary', [])[:5]:
            # Wrap text if too long
            if len(summary_point) > 80:
                words = summary_point.split()
                line = ""
                for word in words:
                    if len(line + word) < 80:
                        line += word + " "
                    else:
                        c.drawString(70, y_pos, "• " + line.strip())
                        y_pos -= 15
                        line = word + " "
                if line:
                    c.drawString(70, y_pos, "  " + line.strip())
                    y_pos -= 15
            else:
                c.drawString(70, y_pos, "• " + summary_point)
                y_pos -= 15
        
        # PAGE 2: Images
        c.showPage()
        
        # Header
        c.setFillColor(primary_color)
        c.rect(0, height - 60, width, 60, fill=True, stroke=False)
        c.setFillColor(HexColor('#ffffff'))
        c.setFont("Helvetica-Bold", 20)
        c.drawString(50, height - 40, "Visual Analysis")
        
        # Annotated Image
        y_pos = height - 100
        c.setFillColor(HexColor('#000000'))
        c.setFont("Helvetica-Bold", 14)
        c.drawString(50, y_pos, "Annotated Roof Image")
        
        if os.path.exists(image_paths['annotated']):
            try:
                img = ImageReader(image_paths['annotated'])
                c.drawImage(img, 50, y_pos - 320, width=500, height=300, preserveAspectRatio=True)
            except Exception as e:
                print(f"Warning: Could not embed annotated image: {e}")
        
        # Comparison Image
        y_pos -= 340
        c.setFont("Helvetica-Bold", 14)
        c.drawString(50, y_pos, "Before & After Enhancement")
        
        if os.path.exists(image_paths['comparison']):
            try:
                img = ImageReader(image_paths['comparison'])
                c.drawImage(img, 50, y_pos - 180, width=500, height=150, preserveAspectRatio=True)
            except Exception as e:
                print(f"Warning: Could not embed comparison image: {e}")
        
        # PAGE 3: Detailed Findings
        c.showPage()
        
        # Header
        c.setFillColor(primary_color)
        c.rect(0, height - 60, width, 60, fill=True, stroke=False)
        c.setFillColor(HexColor('#ffffff'))
        c.setFont("Helvetica-Bold", 20)
        c.drawString(50, height - 40, "Detailed Damage Assessment")
        
        # Damage List
        y_pos = height - 100
        c.setFillColor(HexColor('#000000'))
        
        for i, damage in enumerate(analysis_result['damage_annotations'][:10], 1):  # Max 10
            # Damage header
            c.setFont("Helvetica-Bold", 12)
            damage_title = f"{i}. {damage['type'].replace('_', ' ').title()}"
            c.drawString(50, y_pos, damage_title)
            
            # Severity badge
            severity_color_map = {
                'CRITICAL': danger_color,
                'URGENT': warning_color,
                'MODERATE': HexColor('#3b82f6'),
                'MINOR': success_color
            }
            
            c.setFillColor(severity_color_map.get(damage['severity'], HexColor('#666666')))
            c.rect(300, y_pos - 3, 70, 15, fill=True, stroke=False)
            c.setFillColor(HexColor('#ffffff'))
            c.setFont("Helvetica-Bold", 9)
            c.drawCentredString(335, y_pos, damage['severity'])
            
            c.setFillColor(HexColor('#000000'))
            y_pos -= 20
            
            # Details
            c.setFont("Helvetica", 10)
            c.drawString(70, y_pos, f"Location: {damage['location']}")
            y_pos -= 15
            c.drawString(70, y_pos, f"Coverage: {damage['coverage']:.1f}% of roof")
            y_pos -= 15
            c.drawString(70, y_pos, f"Impact: {damage['impact']}")
            y_pos -= 25
            
            if y_pos < 100:  # New page if running out of space
                c.showPage()
                y_pos = height - 50
        
        # Footer on last page
        c.setFont("Helvetica", 8)
        c.setFillColor(HexColor('#666666'))
        c.drawString(50, 30, "Generated by Aerial Roof Damage Detection System")
        c.drawRightString(width - 50, 30, f"Page {c.getPageNumber()}")
        
        # Save PDF
        c.save()


# Example usage
if __name__ == "__main__":
    # Initialize pipeline
    pipeline = CompleteRoofAnalysisPipeline()
    
    # Load test image
    with open("sample_roof.jpg", "rb") as f:
        image_data = f.read()
    
    # Property data
    property_data = {
        'address': '123 Oak Street, Dallas, TX 75201',
        'year_built': 2005,
        'roof_age_years': 19,
        'property_type': 'Single Family Residential',
        'square_footage': 2400,
        'roof_type': 'Asphalt Shingles'
    }
    
    # Run complete analysis
    results = pipeline.analyze_roof(
        image_data,
        property_data,
        enhancement_level="aggressive",
        output_dir="./roof_analysis_output"
    )
    
    print("\n" + "="*60)
    print("ANALYSIS COMPLETE!")
    print("="*60)
    print(f"\nResults saved to: {results['files']['pdf_report']}")
