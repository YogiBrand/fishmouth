"""
COMPLETE ROOF DAMAGE ANNOTATION SYSTEM
Analyzes roof images with Claude Vision and draws colored annotations
"""

import cv2
import numpy as np
import anthropic
import os
import json
from typing import Dict, List, Tuple
from dataclasses import dataclass
from PIL import Image, ImageDraw, ImageFont
import io
import base64


@dataclass
class DamageAnnotation:
    """Represents a single damage finding"""
    issue_type: str
    severity: str
    severity_color: str
    location_description: str
    location_coordinates: Dict[str, int]  # {left_pct, top_pct}
    coverage_pct: float
    impact: str
    shape: str = "circle"  # circle, rectangle, polygon


class RoofDamageAnnotator:
    """
    Complete annotation system for roof damage detection
    """
    
    # Color mapping for severity levels
    SEVERITY_COLORS = {
        "CRITICAL": (0, 0, 255),      # Red (BGR format)
        "URGENT": (0, 140, 255),      # Orange
        "MODERATE": (0, 255, 255),    # Yellow
        "MINOR": (0, 255, 0),         # Green
        "INFO": (255, 255, 255)       # White
    }
    
    # Color mapping for damage types
    DAMAGE_TYPE_ICONS = {
        "missing_shingles": "❌",
        "granule_loss": "⚠️",
        "curling_cupping": "📐",
        "algae_moss": "🌿",
        "structural_damage": "🏗️",
        "flashing_damage": "⚡",
        "gutter_damage": "💧",
        "chimney_damage": "🔥"
    }
    
    def __init__(self, anthropic_api_key: str = None):
        """Initialize with Anthropic API key"""
        api_key = anthropic_api_key or os.getenv("ANTHROPIC_API_KEY")
        if not api_key:
            raise ValueError("Anthropic API key required")
        
        self.client = anthropic.Anthropic(api_key=api_key)
    
    def analyze_and_annotate(
        self,
        image_base64: str,
        property_data: Dict = None,
        include_specialized_views: bool = True
    ) -> Dict:
        """
        Main function: Analyze roof with Claude Vision and create annotated images
        
        Args:
            image_base64: Base64 encoded image (enhanced)
            property_data: Optional property metadata
            include_specialized_views: Whether to create damage-specific views
            
        Returns:
            Complete analysis with annotated images
        """
        
        # Step 1: Analyze with Claude Vision
        analysis_result = self._analyze_with_claude(image_base64, property_data)
        
        # Step 2: Parse damage findings
        damage_annotations = self._parse_damage_findings(analysis_result)
        
        # Step 3: Create annotated image
        annotated_image = self._create_annotated_image(
            image_base64,
            damage_annotations
        )
        
        # Step 4: Create legend overlay
        image_with_legend = self._add_legend(annotated_image, damage_annotations)
        
        # Step 5: Create specialized damage view overlays (optional)
        specialized_overlays = {}
        if include_specialized_views:
            specialized_overlays = self._create_damage_overlays(
                image_base64,
                damage_annotations
            )
        
        # Step 6: Create summary cards
        summary_cards = self._create_summary_cards(analysis_result, damage_annotations)
        
        return {
            "analysis": analysis_result,
            "damage_annotations": [
                {
                    "type": ann.issue_type,
                    "severity": ann.severity,
                    "location": ann.location_description,
                    "coverage": ann.coverage_pct,
                    "impact": ann.impact
                }
                for ann in damage_annotations
            ],
            "annotated_image": annotated_image,
            "image_with_legend": image_with_legend,
            "specialized_overlays": specialized_overlays,
            "summary_cards": summary_cards
        }
    
    def _analyze_with_claude(self, image_base64: str, property_data: Dict = None) -> Dict:
        """Call Claude Vision API with enhanced prompt"""
        
        property_context = ""
        if property_data:
            property_context = f"""
PROPERTY CONTEXT:
- Address: {property_data.get('address', 'Unknown')}
- Year Built: {property_data.get('year_built', 'Unknown')}
- Estimated Roof Age: {property_data.get('roof_age_years', 'Unknown')} years
- Property Type: {property_data.get('property_type', 'Unknown')}
"""
        
        prompt = f"""You are an expert roofing inspector with 25+ years of experience analyzing aerial roof imagery.

{property_context}

ANALYZE THIS ROOF IMAGE WITH MAXIMUM PRECISION:

PROVIDE EXTREMELY DETAILED DAMAGE MAPPING:

1. **DAMAGE IDENTIFICATION & LOCATION**:
   For EACH issue found, provide:
   - Issue type (missing_shingles, granule_loss, curling_cupping, algae_moss, structural_damage, flashing_damage)
   - Severity (CRITICAL, URGENT, MODERATE, MINOR)
   - Precise location description (e.g., "Northwest corner, near chimney", "South-facing slope, center section")
   - Coordinates as % from edges: {{"left_pct": 0-100, "top_pct": 0-100}}
   - Coverage percentage (% of total roof affected)
   - Impact description (what happens if not fixed)

2. **VISIBLE DAMAGE INDICATORS**:
   - Missing/broken shingles: Count visible instances, describe pattern
   - Granule loss: Describe shiny/bare spots, estimate % affected
   - Curling/cupping: Note which sections, describe severity
   - Algae/moss: Describe color (green/black), location, coverage %
   - Structural issues: Sagging areas, uneven planes, ridge damage
   - Flashing: Condition around chimneys, vents, valleys, edges

3. **MATERIAL ASSESSMENT**:
   - Type: asphalt_shingles, metal, tile, wood_shake, flat_tpo, slate
   - Color: Describe current color vs typical new color
   - Texture: Smooth, rough, patchy, uniform
   - Age indicators: Fading, wear patterns, weathering

4. **PROPERTY-WIDE ISSUES** (Beyond just roofing):
   - Gutters: Sagging, missing sections, clogs visible
   - Chimney: Cracks, mortar damage, flashing issues
   - Trees: Overhanging branches (storm/moss risk)
   - Drainage: Visible water pooling, slope problems
   - Siding: Damage near roofline
   - Ventilation: Visible vent condition

5. **URGENCY & PRIORITY**:
   - IMMEDIATE (0-6 months): Life/property threat
   - URGENT (6-18 months): Significant damage risk
   - PLAN_AHEAD (2-5 years): Preventive replacement
   - GOOD_CONDITION (5+ years): Monitoring only

6. **HOMEOWNER-FRIENDLY SUMMARY**:
   Create 3-5 bullet points that a homeowner can understand, e.g.:
   - "Your roof shows 60% granule loss - typical at 18 years old (normal lifespan: 20 years)"
   - "North-facing slope has 12+ missing shingles creating water intrusion risk"
   - "Moss covering 25% of west side will reduce lifespan by 5-7 years if not treated"

CRITICAL INSTRUCTIONS:
- Be BRUTALLY HONEST. If you can't see the roof clearly, say so and reduce confidence.
- If image quality is poor, flag it and reduce all confidence scores.
- Focus on OBJECTIVE visual indicators, not assumptions.
- Provide ACTIONABLE location data for each finding.

RESPOND IN VALID JSON ONLY (no markdown, no code blocks, no extra text):
{{
  "roof_age_estimate": {{
    "years": <number or null>,
    "confidence": <0-100>,
    "reasoning": "<why this estimate>"
  }},
  "condition_score": <0-100, where 100=perfect new roof, 0=needs immediate replacement>,
  "material_type": "<asphalt_shingles|metal|tile|wood_shake|flat_tpo|slate|unknown>",
  "material_color": "<color description>",
  "roof_pitch": "<flat|low_slope|moderate|steep|unknown>",
  
  "damage_map": [
    {{
      "issue_type": "<missing_shingles|granule_loss|curling_cupping|algae_moss|structural_damage|flashing_damage>",
      "severity": "<CRITICAL|URGENT|MODERATE|MINOR>",
      "severity_color": "<red|orange|yellow|green>",
      "location_description": "<specific location on roof>",
      "location_coordinates": {{
        "left_pct": <0-100>,
        "top_pct": <0-100>
      }},
      "coverage_pct": <0-100>,
      "impact": "<what happens if not addressed>"
    }}
  ],
  
  "damage_summary": {{
    "granule_loss_pct": <0-100>,
    "curling_cupping_pct": <0-100>,
    "missing_shingles_pct": <0-100>,
    "algae_moss_pct": <0-100>,
    "structural_damage_pct": <0-100>
  }},
  
  "property_issues": [
    {{
      "issue": "<description>",
      "severity": "<CRITICAL|URGENT|MODERATE|MINOR>",
      "location": "<where on property>"
    }}
  ],
  
  "replacement_urgency": "<IMMEDIATE|URGENT|PLAN_AHEAD|GOOD_CONDITION>",
  "estimated_remaining_life_years": <number or null>,
  
  "lead_quality": {{
    "score": <0-100>,
    "priority": "<HOT|WARM|COLD>",
    "reasoning": "<why this is a good/bad lead>"
  }},
  
  "homeowner_summary": [
    "<bullet point 1>",
    "<bullet point 2>",
    "<bullet point 3>"
  ],
  
  "inspector_notes": "<detailed professional observations>",
  "image_quality": "<excellent|good|fair|poor>",
  "confidence_overall": <0-100>
}}
"""
        
        try:
            message = self.client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=4000,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "image",
                                "source": {
                                    "type": "base64",
                                    "media_type": "image/jpeg",
                                    "data": image_base64
                                }
                            },
                            {
                                "type": "text",
                                "text": prompt
                            }
                        ]
                    }
                ]
            )
            
            # Parse JSON response
            response_text = message.content[0].text
            
            # Clean up response (remove markdown if present)
            response_text = response_text.strip()
            if response_text.startswith("```json"):
                response_text = response_text[7:]
            if response_text.startswith("```"):
                response_text = response_text[3:]
            if response_text.endswith("```"):
                response_text = response_text[:-3]
            response_text = response_text.strip()
            
            analysis = json.loads(response_text)
            return analysis
            
        except Exception as e:
            print(f"Error calling Claude Vision API: {e}")
            raise
    
    def _parse_damage_findings(self, analysis: Dict) -> List[DamageAnnotation]:
        """Convert Claude's analysis into structured annotations"""
        
        annotations = []
        
        for damage in analysis.get('damage_map', []):
            ann = DamageAnnotation(
                issue_type=damage.get('issue_type', 'unknown'),
                severity=damage.get('severity', 'MODERATE'),
                severity_color=damage.get('severity_color', 'yellow'),
                location_description=damage.get('location_description', ''),
                location_coordinates=damage.get('location_coordinates', {'left_pct': 50, 'top_pct': 50}),
                coverage_pct=damage.get('coverage_pct', 0),
                impact=damage.get('impact', ''),
                shape="circle"
            )
            annotations.append(ann)
        
        return annotations
    
    def _create_annotated_image(
        self,
        image_base64: str,
        annotations: List[DamageAnnotation]
    ) -> np.ndarray:
        """Draw colored shapes and labels on the image"""
        
        # Decode base64 image
        img_data = base64.b64decode(image_base64)
        nparr = np.frombuffer(img_data, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        if img is None:
            raise ValueError("Failed to decode image")
        
        height, width = img.shape[:2]
        
        # Create semi-transparent overlay
        overlay = img.copy()
        
        # Draw each annotation
        for i, ann in enumerate(annotations):
            # Calculate pixel coordinates
            x = int(width * ann.location_coordinates['left_pct'] / 100)
            y = int(height * ann.location_coordinates['top_pct'] / 100)
            
            # Get color based on severity
            color = self.SEVERITY_COLORS.get(ann.severity, (255, 255, 255))
            
            # Calculate size based on coverage
            base_radius = 30
            radius = int(base_radius + (ann.coverage_pct / 100) * 40)
            
            # Draw damage indicator
            if ann.shape == "circle":
                # Draw filled circle
                cv2.circle(overlay, (x, y), radius, color, -1)
                # Draw border
                cv2.circle(img, (x, y), radius, color, 4)
            
            # Draw label background
            label_text = f"{ann.issue_type.replace('_', ' ').title()}"
            label_size = cv2.getTextSize(label_text, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)[0]
            
            # Label position (above the marker)
            label_x = x - label_size[0] // 2
            label_y = y - radius - 10
            
            # Ensure label stays in bounds
            label_x = max(5, min(label_x, width - label_size[0] - 5))
            label_y = max(label_size[1] + 5, label_y)
            
            # Draw label background
            cv2.rectangle(img,
                         (label_x - 5, label_y - label_size[1] - 5),
                         (label_x + label_size[0] + 5, label_y + 5),
                         color, -1)
            
            # Draw label text
            cv2.putText(img, label_text,
                       (label_x, label_y),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            
            # Draw coverage percentage
            coverage_text = f"{ann.coverage_pct:.0f}%"
            cv2.putText(img, coverage_text,
                       (x - 15, y + 5),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)
            
            # Draw severity indicator
            severity_badge = ann.severity[:1]  # First letter
            cv2.circle(img, (x + radius + 15, y - radius - 15), 15, color, -1)
            cv2.putText(img, severity_badge,
                       (x + radius + 8, y - radius - 8),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        
        # Blend overlay for semi-transparency
        alpha = 0.3
        img = cv2.addWeighted(overlay, alpha, img, 1 - alpha, 0)
        
        return img
    
    def _add_legend(self, img: np.ndarray, annotations: List[DamageAnnotation]) -> np.ndarray:
        """Add legend/key to the annotated image"""
        
        height, width = img.shape[:2]
        
        # Create legend area (right side)
        legend_width = 300
        legend_img = img.copy()
        
        # Draw semi-transparent legend background
        cv2.rectangle(legend_img,
                     (width - legend_width - 20, 20),
                     (width - 20, height - 20),
                     (0, 0, 0), -1)
        
        # Blend for transparency
        img = cv2.addWeighted(legend_img, 0.7, img, 0.3, 0)
        
        # Legend title
        cv2.putText(img, "DAMAGE LEGEND",
                   (width - legend_width, 50),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        
        # Draw severity scale
        y_pos = 90
        for severity, color in self.SEVERITY_COLORS.items():
            if severity == "INFO":
                continue
            
            # Draw color box
            cv2.rectangle(img,
                         (width - legend_width, y_pos),
                         (width - legend_width + 30, y_pos + 20),
                         color, -1)
            
            # Draw label
            cv2.putText(img, severity,
                       (width - legend_width + 40, y_pos + 15),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            
            y_pos += 30
        
        # Draw damage type counts
        y_pos += 20
        cv2.putText(img, "ISSUES FOUND:",
                   (width - legend_width, y_pos),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        y_pos += 25
        
        # Count damage types
        damage_counts = {}
        for ann in annotations:
            damage_counts[ann.issue_type] = damage_counts.get(ann.issue_type, 0) + 1
        
        for damage_type, count in damage_counts.items():
            display_name = damage_type.replace('_', ' ').title()
            text = f"{display_name}: {count}"
            cv2.putText(img, text,
                       (width - legend_width, y_pos),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)
            y_pos += 20
        
        # Add totals
        y_pos += 10
        total_text = f"TOTAL: {len(annotations)} issues"
        cv2.putText(img, total_text,
                   (width - legend_width, y_pos),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 0), 2)
        
        return img
    
    def _create_damage_overlays(
        self,
        image_base64: str,
        annotations: List[DamageAnnotation]
    ) -> Dict[str, np.ndarray]:
        """Create specialized overlay views for different damage types"""
        
        # Decode image
        img_data = base64.b64decode(image_base64)
        nparr = np.frombuffer(img_data, np.uint8)
        base_img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        overlays = {}
        
        # Group annotations by type
        damage_groups = {}
        for ann in annotations:
            if ann.issue_type not in damage_groups:
                damage_groups[ann.issue_type] = []
            damage_groups[ann.issue_type].append(ann)
        
        # Create overlay for each damage type
        for damage_type, anns in damage_groups.items():
            overlay = base_img.copy()
            
            # Create heatmap
            height, width = overlay.shape[:2]
            heatmap = np.zeros((height, width), dtype=np.float32)
            
            for ann in anns:
                x = int(width * ann.location_coordinates['left_pct'] / 100)
                y = int(height * ann.location_coordinates['top_pct'] / 100)
                radius = int(50 + (ann.coverage_pct / 100) * 100)
                
                # Create gradient
                cv2.circle(heatmap, (x, y), radius, ann.coverage_pct, -1)
            
            # Normalize and apply colormap
            heatmap_normalized = cv2.normalize(heatmap, None, 0, 255, cv2.NORM_MINMAX).astype('uint8')
            heatmap_colored = cv2.applyColorMap(heatmap_normalized, cv2.COLORMAP_JET)
            
            # Blend with original
            overlay = cv2.addWeighted(overlay, 0.6, heatmap_colored, 0.4, 0)
            
            overlays[damage_type] = overlay
        
        return overlays
    
    def _create_summary_cards(
        self,
        analysis: Dict,
        annotations: List[DamageAnnotation]
    ) -> Dict:
        """Create summary data for visual cards/reports"""
        
        # Count by severity
        severity_counts = {
            "CRITICAL": 0,
            "URGENT": 0,
            "MODERATE": 0,
            "MINOR": 0
        }
        
        for ann in annotations:
            severity_counts[ann.severity] = severity_counts.get(ann.severity, 0) + 1
        
        # Calculate priority score
        priority_score = (
            severity_counts["CRITICAL"] * 100 +
            severity_counts["URGENT"] * 50 +
            severity_counts["MODERATE"] * 20 +
            severity_counts["MINOR"] * 5
        )
        
        return {
            "total_issues": len(annotations),
            "severity_breakdown": severity_counts,
            "priority_score": priority_score,
            "condition_score": analysis.get('condition_score', 0),
            "urgency": analysis.get('replacement_urgency', 'UNKNOWN'),
            "lead_quality": analysis.get('lead_quality', {}),
            "remaining_life": analysis.get('estimated_remaining_life_years'),
            "homeowner_summary": analysis.get('homeowner_summary', [])
        }
    
    def save_annotated_image(self, img: np.ndarray, output_path: str, quality: int = 95):
        """Save annotated image to file"""
        cv2.imwrite(output_path, img, [cv2.IMWRITE_JPEG_QUALITY, quality])
        print(f"✓ Saved annotated image: {output_path}")


# Example usage
if __name__ == "__main__":
    # Initialize
    annotator = RoofDamageAnnotator()
    
    # Load and enhance image first
    with open("sample_roof.jpg", "rb") as f:
        image_data = f.read()
    
    from image_enhancer import enhance_satellite_image
    
    # Enhance image
    enhanced = enhance_satellite_image(image_data, level="aggressive")
    
    # Analyze and annotate
    result = annotator.analyze_and_annotate(
        enhanced['enhanced_base64'],
        property_data={
            'address': '123 Main St, Dallas, TX',
            'year_built': 2005,
            'roof_age_years': 19
        }
    )
    
    # Save results
    annotator.save_annotated_image(
        result['annotated_image'],
        "annotated_roof.jpg"
    )
    
    annotator.save_annotated_image(
        result['image_with_legend'],
        "annotated_roof_with_legend.jpg"
    )
    
    # Save specialized views
    for damage_type, overlay in result['specialized_overlays'].items():
        annotator.save_annotated_image(
            overlay,
            f"overlay_{damage_type}.jpg"
        )
    
    print("\n" + "="*60)
    print("ANALYSIS SUMMARY")
    print("="*60)
    print(f"Total Issues Found: {result['summary_cards']['total_issues']}")
    print(f"Condition Score: {result['summary_cards']['condition_score']}/100")
    print(f"Urgency: {result['summary_cards']['urgency']}")
    print(f"Lead Quality: {result['summary_cards']['lead_quality']['priority']}")
    print("\nSeverity Breakdown:")
    for severity, count in result['summary_cards']['severity_breakdown'].items():
        if count > 0:
            print(f"  {severity}: {count}")
