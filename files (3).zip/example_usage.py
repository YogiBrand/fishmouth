"""
EXAMPLE: Complete Roof Analysis Usage
This script demonstrates all features of the roof analysis system
"""

import os
from complete_pipeline import CompleteRoofAnalysisPipeline
from image_enhancer import enhance_satellite_image
from roof_annotator import RoofDamageAnnotator

def example_1_basic_analysis():
    """Example 1: Basic single roof analysis"""
    
    print("\n" + "="*60)
    print("EXAMPLE 1: Basic Single Roof Analysis")
    print("="*60)
    
    # Initialize pipeline
    pipeline = CompleteRoofAnalysisPipeline()
    
    # Load image (replace with your actual image)
    image_path = "sample_roof.jpg"
    
    if not os.path.exists(image_path):
        print(f"❌ Error: {image_path} not found. Please provide a roof satellite image.")
        return
    
    with open(image_path, "rb") as f:
        image_data = f.read()
    
    # Property data
    property_data = {
        'address': '123 Oak Street, Dallas, TX 75201',
        'year_built': 2005,
        'roof_age_years': 19,
        'property_type': 'Single Family Residential',
        'square_footage': 2400
    }
    
    # Run analysis
    results = pipeline.analyze_roof(
        image_data,
        property_data,
        enhancement_level="aggressive",
        output_dir="./example_output"
    )
    
    # Display results
    print("\n✅ ANALYSIS COMPLETE!")
    print(f"\n📊 Summary:")
    print(f"  Condition Score: {results['summary_cards']['condition_score']}/100")
    print(f"  Total Issues: {results['summary_cards']['total_issues']}")
    print(f"  Lead Priority: {results['summary_cards']['lead_quality']['priority']}")
    print(f"  Urgency: {results['summary_cards']['urgency']}")
    print(f"\n📁 Files saved to: ./example_output/")


def example_2_image_enhancement_only():
    """Example 2: Just enhance an image without full analysis"""
    
    print("\n" + "="*60)
    print("EXAMPLE 2: Image Enhancement Only")
    print("="*60)
    
    image_path = "sample_roof.jpg"
    
    if not os.path.exists(image_path):
        print(f"❌ Error: {image_path} not found.")
        return
    
    with open(image_path, "rb") as f:
        image_data = f.read()
    
    # Enhance image
    result = enhance_satellite_image(image_data, level="aggressive")
    
    print("\n✅ Enhancement complete!")
    print(f"Stages applied: {len(result['enhancement_log'])}")
    for stage in result['enhancement_log']:
        print(f"  ✓ {stage}")
    
    # Save results
    import cv2
    cv2.imwrite("enhanced_output.jpg", result['enhanced_final'])
    print("\n💾 Saved: enhanced_output.jpg")
    
    # Save specialized views
    for view_name, view_img in result['specialized_views'].items():
        output_path = f"view_{view_name}.jpg"
        cv2.imwrite(output_path, view_img)
        print(f"💾 Saved: {output_path}")


def example_3_annotation_only():
    """Example 3: Analyze and annotate (no full pipeline)"""
    
    print("\n" + "="*60)
    print("EXAMPLE 3: Analysis & Annotation Only")
    print("="*60)
    
    image_path = "sample_roof.jpg"
    
    if not os.path.exists(image_path):
        print(f"❌ Error: {image_path} not found.")
        return
    
    with open(image_path, "rb") as f:
        image_data = f.read()
    
    # First enhance
    enhanced = enhance_satellite_image(image_data, level="aggressive")
    
    # Then annotate
    annotator = RoofDamageAnnotator()
    
    property_data = {
        'address': '123 Main St',
        'year_built': 2005,
        'roof_age_years': 19
    }
    
    result = annotator.analyze_and_annotate(
        enhanced['enhanced_base64'],
        property_data
    )
    
    print("\n✅ Analysis complete!")
    print(f"\nDamage found: {len(result['damage_annotations'])} issues")
    
    for damage in result['damage_annotations']:
        print(f"\n  🔴 {damage['type'].replace('_', ' ').title()}")
        print(f"     Severity: {damage['severity']}")
        print(f"     Location: {damage['location']}")
        print(f"     Coverage: {damage['coverage']:.1f}%")
    
    # Save annotated image
    import cv2
    cv2.imwrite("annotated_result.jpg", result['image_with_legend'])
    print("\n💾 Saved: annotated_result.jpg")


def example_4_batch_processing():
    """Example 4: Process multiple roofs"""
    
    print("\n" + "="*60)
    print("EXAMPLE 4: Batch Processing")
    print("="*60)
    
    # Simulate multiple properties
    properties = [
        {
            'image_path': 'roof1.jpg',
            'data': {
                'address': '123 Main St, Dallas, TX',
                'year_built': 2005,
                'roof_age_years': 19
            }
        },
        {
            'image_path': 'roof2.jpg',
            'data': {
                'address': '456 Oak Ave, Dallas, TX',
                'year_built': 2010,
                'roof_age_years': 14
            }
        }
    ]
    
    pipeline = CompleteRoofAnalysisPipeline()
    results = []
    
    for i, prop in enumerate(properties, 1):
        if not os.path.exists(prop['image_path']):
            print(f"\n⚠️  Skipping {prop['data']['address']} - image not found")
            continue
        
        print(f"\n📍 Processing {i}/{len(properties)}: {prop['data']['address']}")
        
        with open(prop['image_path'], 'rb') as f:
            image_data = f.read()
        
        result = pipeline.analyze_roof(
            image_data,
            prop['data'],
            enhancement_level="aggressive",
            output_dir=f"./batch_output/property_{i}"
        )
        
        results.append({
            'address': prop['data']['address'],
            'condition_score': result['summary_cards']['condition_score'],
            'total_issues': result['summary_cards']['total_issues'],
            'lead_priority': result['summary_cards']['lead_quality']['priority']
        })
    
    # Summary
    print("\n" + "="*60)
    print("BATCH PROCESSING COMPLETE")
    print("="*60)
    
    for result in results:
        print(f"\n📍 {result['address']}")
        print(f"   Score: {result['condition_score']}/100")
        print(f"   Issues: {result['total_issues']}")
        print(f"   Priority: {result['lead_priority']}")
    
    # Sort by priority
    hot_leads = [r for r in results if r['lead_priority'] == 'HOT']
    print(f"\n🔥 Found {len(hot_leads)} HOT leads!")


def example_5_api_integration():
    """Example 5: Using the REST API"""
    
    print("\n" + "="*60)
    print("EXAMPLE 5: REST API Integration")
    print("="*60)
    
    print("\n💡 To use the REST API:")
    print("\n1. Start the API server:")
    print("   $ python api_server.py")
    print("\n2. Make a request:")
    print("""
   curl -X POST "http://localhost:8000/api/analyze" \\
     -F "image=@roof_satellite.jpg" \\
     -F "address=123 Main St, Dallas, TX" \\
     -F "year_built=2005" \\
     -F "roof_age_years=19"
    """)
    print("\n3. Download the PDF report:")
    print("""
   curl "http://localhost:8000/api/download/{analysis_id}/report" \\
     -o report.pdf
    """)
    print("\n4. View interactive docs:")
    print("   http://localhost:8000/docs")


def main():
    """Run all examples"""
    
    print("""
    ╔════════════════════════════════════════════════════════════╗
    ║   ROOF DAMAGE DETECTION SYSTEM - EXAMPLES & USAGE          ║
    ╚════════════════════════════════════════════════════════════╝
    """)
    
    print("\nAvailable examples:")
    print("  1. Basic single roof analysis (full pipeline)")
    print("  2. Image enhancement only")
    print("  3. Analysis & annotation only")
    print("  4. Batch processing multiple roofs")
    print("  5. REST API integration guide")
    
    choice = input("\nSelect example (1-5, or 'all' to run all): ").strip()
    
    if choice == '1':
        example_1_basic_analysis()
    elif choice == '2':
        example_2_image_enhancement_only()
    elif choice == '3':
        example_3_annotation_only()
    elif choice == '4':
        example_4_batch_processing()
    elif choice == '5':
        example_5_api_integration()
    elif choice.lower() == 'all':
        example_1_basic_analysis()
        example_2_image_enhancement_only()
        example_3_annotation_only()
        example_4_batch_processing()
        example_5_api_integration()
    else:
        print("Invalid choice. Please run again and select 1-5 or 'all'.")


if __name__ == "__main__":
    main()
