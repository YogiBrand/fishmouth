"""
ADVANCED IMAGE ENHANCEMENT PIPELINE FOR ROOF DAMAGE DETECTION
This module preprocesses satellite imagery to maximize visibility of roof defects
"""

import cv2
import numpy as np
from PIL import Image, ImageEnhance, ImageFilter
import io
import base64
from typing import Dict, List, Tuple

class RoofImageEnhancer:
    """
    Multi-stage image enhancement pipeline to make roof defects crystal clear
    """
    
    def __init__(self):
        self.enhancement_stages = []
        
    def enhance_image(self, image_data: bytes, enhancement_level: str = "aggressive") -> Dict:
        """
        Main enhancement pipeline
        
        Args:
            image_data: Raw image bytes from satellite API
            enhancement_level: "light", "moderate", or "aggressive"
            
        Returns:
            Dict with original, enhanced, and analysis-ready images
        """
        
        # Convert to OpenCV format
        nparr = np.frombuffer(image_data, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        if img is None:
            raise ValueError("Failed to decode image")
        
        # Store original
        original_img = img.copy()
        
        # Enhancement pipeline
        enhanced_images = {}
        
        # Stage 1: Basic Enhancement
        img_basic = self._basic_enhancement(img)
        enhanced_images['basic'] = img_basic
        
        # Stage 2: Adaptive Histogram Equalization (CLAHE)
        img_clahe = self._apply_clahe(img_basic)
        enhanced_images['clahe'] = img_clahe
        
        # Stage 3: Sharpening
        img_sharp = self._sharpen_image(img_clahe)
        enhanced_images['sharpened'] = img_sharp
        
        # Stage 4: Edge Enhancement
        img_edges = self._enhance_edges(img_sharp)
        enhanced_images['edge_enhanced'] = img_edges
        
        # Stage 5: Contrast Boost
        img_contrast = self._boost_contrast(img_edges)
        enhanced_images['contrast_boosted'] = img_contrast
        
        # Stage 6: Color Correction for Roof Analysis
        img_color = self._roof_color_correction(img_contrast)
        enhanced_images['color_corrected'] = img_color
        
        # Stage 7: Noise Reduction (final cleanup)
        img_final = self._denoise(img_color)
        enhanced_images['final'] = img_final
        
        # Create specialized views for different damage types
        specialized_views = self._create_specialized_views(img_final)
        
        # Convert to base64 for API transmission
        final_base64 = self._image_to_base64(img_final)
        
        return {
            'original': original_img,
            'enhanced_final': img_final,
            'enhanced_base64': final_base64,
            'enhancement_stages': enhanced_images,
            'specialized_views': specialized_views,
            'enhancement_log': self.enhancement_stages
        }
    
    def _basic_enhancement(self, img: np.ndarray) -> np.ndarray:
        """Stage 1: Basic brightness, contrast, saturation boost"""
        self.enhancement_stages.append("Basic Enhancement")
        
        # Convert to PIL for easy manipulation
        pil_img = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
        
        # Brightness boost
        enhancer = ImageEnhance.Brightness(pil_img)
        pil_img = enhancer.enhance(1.15)
        
        # Contrast boost
        enhancer = ImageEnhance.Contrast(pil_img)
        pil_img = enhancer.enhance(1.25)
        
        # Saturation boost (helps identify discoloration)
        enhancer = ImageEnhance.Color(pil_img)
        pil_img = enhancer.enhance(1.2)
        
        # Convert back to OpenCV
        return cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)
    
    def _apply_clahe(self, img: np.ndarray) -> np.ndarray:
        """Stage 2: Contrast Limited Adaptive Histogram Equalization"""
        self.enhancement_stages.append("CLAHE (Adaptive Histogram Equalization)")
        
        # Convert to LAB color space
        lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        
        # Apply CLAHE to L channel
        clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
        l_clahe = clahe.apply(l)
        
        # Merge and convert back
        lab_clahe = cv2.merge([l_clahe, a, b])
        return cv2.cvtColor(lab_clahe, cv2.COLOR_LAB2BGR)
    
    def _sharpen_image(self, img: np.ndarray) -> np.ndarray:
        """Stage 3: Advanced sharpening to reveal fine details"""
        self.enhancement_stages.append("Sharpening")
        
        # Create sharpening kernel
        kernel_sharp = np.array([
            [-1, -1, -1],
            [-1,  9, -1],
            [-1, -1, -1]
        ])
        
        # Apply sharpening
        sharpened = cv2.filter2D(img, -1, kernel_sharp)
        
        # Blend with original (70% sharpened, 30% original)
        return cv2.addWeighted(sharpened, 0.7, img, 0.3, 0)
    
    def _enhance_edges(self, img: np.ndarray) -> np.ndarray:
        """Stage 4: Edge enhancement to make shingle lines visible"""
        self.enhancement_stages.append("Edge Enhancement")
        
        # Convert to grayscale for edge detection
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        # Apply bilateral filter to preserve edges while smoothing
        smooth = cv2.bilateralFilter(gray, 9, 75, 75)
        
        # Detect edges using Canny
        edges = cv2.Canny(smooth, 50, 150)
        
        # Create an edge mask
        edges_colored = cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)
        
        # Blend edges with original image
        return cv2.addWeighted(img, 0.9, edges_colored, 0.1, 0)
    
    def _boost_contrast(self, img: np.ndarray) -> np.ndarray:
        """Stage 5: Aggressive contrast boost for damage visibility"""
        self.enhancement_stages.append("Contrast Boost")
        
        # Convert to YUV color space
        yuv = cv2.cvtColor(img, cv2.COLOR_BGR2YUV)
        y, u, v = cv2.split(yuv)
        
        # Normalize Y channel (brightness)
        y_normalized = cv2.normalize(y, None, 0, 255, cv2.NORM_MINMAX)
        
        # Apply gamma correction (makes dark areas darker, bright areas brighter)
        gamma = 1.2
        inv_gamma = 1.0 / gamma
        table = np.array([((i / 255.0) ** inv_gamma) * 255
                         for i in range(256)]).astype("uint8")
        y_gamma = cv2.LUT(y_normalized, table)
        
        # Merge and convert back
        yuv_enhanced = cv2.merge([y_gamma, u, v])
        return cv2.cvtColor(yuv_enhanced, cv2.COLOR_YUV2BGR)
    
    def _roof_color_correction(self, img: np.ndarray) -> np.ndarray:
        """Stage 6: Color correction optimized for roof material detection"""
        self.enhancement_stages.append("Roof-Specific Color Correction")
        
        # Enhance specific color ranges that indicate damage
        
        # 1. Boost browns/grays (worn shingles)
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        h, s, v = cv2.split(hsv)
        
        # Increase saturation slightly to differentiate colors
        s = cv2.convertScaleAbs(s, alpha=1.2, beta=10)
        s = np.clip(s, 0, 255)
        
        # Boost value (brightness) for better visibility
        v = cv2.convertScaleAbs(v, alpha=1.1, beta=5)
        v = np.clip(v, 0, 255)
        
        hsv_corrected = cv2.merge([h, s, v])
        img_corrected = cv2.cvtColor(hsv_corrected, cv2.COLOR_HSV2BGR)
        
        # 2. Enhance green channel (moss/algae detection)
        b, g, r = cv2.split(img_corrected)
        g = cv2.convertScaleAbs(g, alpha=1.15, beta=5)
        
        return cv2.merge([b, g, r])
    
    def _denoise(self, img: np.ndarray) -> np.ndarray:
        """Stage 7: Final noise reduction while preserving details"""
        self.enhancement_stages.append("Noise Reduction")
        
        # Non-local means denoising (best for preserving details)
        return cv2.fastNlMeansDenoisingColored(img, None, 10, 10, 7, 21)
    
    def _create_specialized_views(self, img: np.ndarray) -> Dict[str, np.ndarray]:
        """Create specialized image views for different damage types"""
        
        views = {}
        
        # 1. Granule Loss View (emphasizes texture loss)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        texture = cv2.Laplacian(gray, cv2.CV_64F)
        texture_normalized = cv2.normalize(np.abs(texture), None, 0, 255, cv2.NORM_MINMAX).astype('uint8')
        views['granule_loss'] = cv2.applyColorMap(texture_normalized, cv2.COLORMAP_JET)
        
        # 2. Moss/Algae View (emphasizes green/dark areas)
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        
        # Mask for green/dark areas (moss/algae)
        lower_green = np.array([35, 40, 40])
        upper_green = np.array([85, 255, 255])
        mask_green = cv2.inRange(hsv, lower_green, upper_green)
        
        # Mask for dark areas (algae)
        lower_dark = np.array([0, 0, 0])
        upper_dark = np.array([180, 255, 50])
        mask_dark = cv2.inRange(hsv, lower_dark, upper_dark)
        
        # Combine masks
        algae_mask = cv2.bitwise_or(mask_green, mask_dark)
        views['algae_detection'] = cv2.applyColorMap(algae_mask, cv2.COLORMAP_HOT)
        
        # 3. Missing Shingles View (emphasizes discontinuities)
        edges = cv2.Canny(gray, 100, 200)
        views['missing_shingles'] = cv2.applyColorMap(edges, cv2.COLORMAP_BONE)
        
        # 4. Thermal Gradient View (simulated - shows uneven coloring)
        lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        views['thermal_gradient'] = cv2.applyColorMap(l, cv2.COLORMAP_RAINBOW)
        
        # 5. Structural Integrity View (highlights sagging/warping)
        sobel_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=5)
        sobel_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=5)
        sobel_combined = np.sqrt(sobel_x**2 + sobel_y**2)
        sobel_normalized = cv2.normalize(sobel_combined, None, 0, 255, cv2.NORM_MINMAX).astype('uint8')
        views['structural_integrity'] = cv2.applyColorMap(sobel_normalized, cv2.COLORMAP_VIRIDIS)
        
        return views
    
    def _image_to_base64(self, img: np.ndarray, format: str = 'JPEG') -> str:
        """Convert OpenCV image to base64 string"""
        
        # Convert BGR to RGB
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        
        # Convert to PIL
        pil_img = Image.fromarray(img_rgb)
        
        # Save to buffer
        buffer = io.BytesIO()
        pil_img.save(buffer, format=format, quality=95)
        buffer.seek(0)
        
        # Encode to base64
        return base64.b64encode(buffer.getvalue()).decode('utf-8')
    
    def compare_before_after(self, original: np.ndarray, enhanced: np.ndarray) -> np.ndarray:
        """Create side-by-side comparison image"""
        
        # Resize if needed
        h, w = original.shape[:2]
        
        # Create canvas
        comparison = np.zeros((h, w * 2, 3), dtype=np.uint8)
        
        # Add images
        comparison[:, :w] = original
        comparison[:, w:] = enhanced
        
        # Add labels
        cv2.putText(comparison, "ORIGINAL", (20, 40),
                   cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        cv2.putText(comparison, "ENHANCED", (w + 20, 40),
                   cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        
        return comparison


def enhance_satellite_image(image_bytes: bytes, level: str = "aggressive") -> Dict:
    """
    Convenience function to enhance a satellite image
    
    Usage:
        result = enhance_satellite_image(image_data, level="aggressive")
        enhanced_base64 = result['enhanced_base64']
    """
    
    enhancer = RoofImageEnhancer()
    return enhancer.enhance_image(image_bytes, level)


# Example usage
if __name__ == "__main__":
    # Test with a sample image
    with open("sample_roof.jpg", "rb") as f:
        image_data = f.read()
    
    result = enhance_satellite_image(image_data)
    
    print("Enhancement stages applied:")
    for stage in result['enhancement_log']:
        print(f"  ✓ {stage}")
    
    print(f"\nSpecialized views created: {list(result['specialized_views'].keys())}")
    
    # Save enhanced image
    cv2.imwrite("enhanced_roof.jpg", result['enhanced_final'])
    
    # Save comparison
    enhancer = RoofImageEnhancer()
    comparison = enhancer.compare_before_after(
        result['original'],
        result['enhanced_final']
    )
    cv2.imwrite("comparison.jpg", comparison)
    
    print("\n✓ Enhanced image saved as 'enhanced_roof.jpg'")
    print("✓ Comparison saved as 'comparison.jpg'")
