"""
FASTAPI WRAPPER FOR ROOF ANALYSIS SYSTEM
Easy REST API integration for the roofing app backend
"""

from fastapi import FastAPI, File, UploadFile, Form, HTTPException
from fastapi.responses import JSONResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, Dict
import os
import uuid
import shutil
from datetime import datetime

from complete_pipeline import CompleteRoofAnalysisPipeline

app = FastAPI(
    title="Roof Damage Analysis API",
    description="AI-powered aerial roof damage detection and annotation",
    version="1.0.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize pipeline
pipeline = CompleteRoofAnalysisPipeline()

# Store results temporarily (in production, use S3 or database)
TEMP_RESULTS_DIR = "./temp_analysis_results"
os.makedirs(TEMP_RESULTS_DIR, exist_ok=True)


class PropertyData(BaseModel):
    address: str
    year_built: Optional[int] = None
    roof_age_years: Optional[int] = None
    property_type: Optional[str] = "Single Family"
    square_footage: Optional[int] = None


class AnalysisRequest(BaseModel):
    property_data: PropertyData
    enhancement_level: str = "aggressive"  # light, moderate, aggressive


@app.get("/")
def root():
    return {
        "service": "Roof Damage Analysis API",
        "version": "1.0.0",
        "status": "operational",
        "endpoints": {
            "analyze": "POST /api/analyze - Analyze roof from satellite image",
            "health": "GET /health - Check API health",
            "results": "GET /api/results/{analysis_id} - Get analysis results"
        }
    }


@app.get("/health")
def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "pipeline_ready": True
    }


@app.post("/api/analyze")
async def analyze_roof(
    image: UploadFile = File(...),
    address: str = Form(...),
    year_built: Optional[int] = Form(None),
    roof_age_years: Optional[int] = Form(None),
    property_type: str = Form("Single Family"),
    enhancement_level: str = Form("aggressive")
):
    """
    Analyze a roof from satellite imagery
    
    Parameters:
    - image: Satellite image file (JPEG/PNG)
    - address: Property address
    - year_built: Year the property was built
    - roof_age_years: Age of the roof in years
    - property_type: Type of property
    - enhancement_level: Image enhancement level (light, moderate, aggressive)
    
    Returns:
    - Complete analysis with annotated images and PDF report
    """
    
    try:
        # Generate unique analysis ID
        analysis_id = str(uuid.uuid4())
        output_dir = os.path.join(TEMP_RESULTS_DIR, analysis_id)
        os.makedirs(output_dir, exist_ok=True)
        
        # Read image data
        image_data = await image.read()
        
        # Prepare property data
        property_data = {
            'address': address,
            'year_built': year_built,
            'roof_age_years': roof_age_years,
            'property_type': property_type
        }
        
        # Run analysis
        results = pipeline.analyze_roof(
            image_data,
            property_data,
            enhancement_level=enhancement_level,
            output_dir=output_dir
        )
        
        # Add analysis ID to results
        results['analysis_id'] = analysis_id
        
        # Return summary with file URLs
        return JSONResponse({
            "success": True,
            "analysis_id": analysis_id,
            "summary": {
                "condition_score": results['analysis']['condition_score'],
                "total_issues": results['summary_cards']['total_issues'],
                "severity_breakdown": results['summary_cards']['severity_breakdown'],
                "urgency": results['analysis']['replacement_urgency'],
                "lead_priority": results['summary_cards']['lead_quality']['priority'],
                "estimated_remaining_life": results['summary_cards']['remaining_life']
            },
            "files": {
                "pdf_report": f"/api/download/{analysis_id}/report",
                "annotated_image": f"/api/download/{analysis_id}/annotated",
                "enhanced_image": f"/api/download/{analysis_id}/enhanced",
                "all_files": f"/api/results/{analysis_id}"
            },
            "damage_annotations": results['damage_annotations'],
            "homeowner_summary": results['analysis']['homeowner_summary']
        })
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/results/{analysis_id}")
def get_results(analysis_id: str):
    """Get complete analysis results by ID"""
    
    result_dir = os.path.join(TEMP_RESULTS_DIR, analysis_id)
    json_file = None
    
    # Find the JSON file
    for file in os.listdir(result_dir):
        if file.endswith('_data.json'):
            json_file = os.path.join(result_dir, file)
            break
    
    if not json_file or not os.path.exists(json_file):
        raise HTTPException(status_code=404, detail="Analysis not found")
    
    import json
    with open(json_file, 'r') as f:
        data = json.load(f)
    
    return data


@app.get("/api/download/{analysis_id}/{file_type}")
def download_file(analysis_id: str, file_type: str):
    """
    Download specific file from analysis
    
    file_type options:
    - report: PDF report
    - annotated: Annotated image with legend
    - enhanced: Enhanced satellite image
    - comparison: Before/after comparison
    """
    
    result_dir = os.path.join(TEMP_RESULTS_DIR, analysis_id)
    
    if not os.path.exists(result_dir):
        raise HTTPException(status_code=404, detail="Analysis not found")
    
    # Map file types to file patterns
    file_patterns = {
        'report': '_report.pdf',
        'annotated': '_annotated_legend.jpg',
        'enhanced': '_enhanced.jpg',
        'comparison': '_comparison.jpg'
    }
    
    pattern = file_patterns.get(file_type)
    if not pattern:
        raise HTTPException(status_code=400, detail="Invalid file type")
    
    # Find matching file
    for file in os.listdir(result_dir):
        if pattern in file:
            file_path = os.path.join(result_dir, file)
            
            # Determine media type
            if file.endswith('.pdf'):
                media_type = 'application/pdf'
            elif file.endswith('.jpg') or file.endswith('.jpeg'):
                media_type = 'image/jpeg'
            else:
                media_type = 'application/octet-stream'
            
            return FileResponse(
                file_path,
                media_type=media_type,
                filename=file
            )
    
    raise HTTPException(status_code=404, detail="File not found")


@app.delete("/api/results/{analysis_id}")
def delete_results(analysis_id: str):
    """Delete analysis results (cleanup)"""
    
    result_dir = os.path.join(TEMP_RESULTS_DIR, analysis_id)
    
    if os.path.exists(result_dir):
        shutil.rmtree(result_dir)
        return {"success": True, "message": "Results deleted"}
    
    raise HTTPException(status_code=404, detail="Analysis not found")


# Batch analysis endpoint
@app.post("/api/batch-analyze")
async def batch_analyze(
    images: list[UploadFile] = File(...),
    property_data_json: str = Form(...)
):
    """
    Batch analyze multiple roofs
    
    Parameters:
    - images: List of satellite images
    - property_data_json: JSON string with array of property data
    
    Returns:
    - Analysis results for all properties
    """
    
    import json
    property_data_list = json.loads(property_data_json)
    
    if len(images) != len(property_data_list):
        raise HTTPException(
            status_code=400,
            detail="Number of images must match number of property data entries"
        )
    
    results = []
    
    for image, prop_data in zip(images, property_data_list):
        try:
            # Generate unique ID
            analysis_id = str(uuid.uuid4())
            output_dir = os.path.join(TEMP_RESULTS_DIR, analysis_id)
            os.makedirs(output_dir, exist_ok=True)
            
            # Read image
            image_data = await image.read()
            
            # Run analysis
            analysis_result = pipeline.analyze_roof(
                image_data,
                prop_data,
                enhancement_level="aggressive",
                output_dir=output_dir
            )
            
            results.append({
                "analysis_id": analysis_id,
                "property": prop_data,
                "summary": {
                    "condition_score": analysis_result['analysis']['condition_score'],
                    "total_issues": analysis_result['summary_cards']['total_issues'],
                    "urgency": analysis_result['analysis']['replacement_urgency'],
                    "lead_priority": analysis_result['summary_cards']['lead_quality']['priority']
                }
            })
            
        except Exception as e:
            results.append({
                "property": prop_data,
                "error": str(e)
            })
    
    return {
        "success": True,
        "total_analyzed": len(results),
        "results": results
    }


if __name__ == "__main__":
    import uvicorn
    
    print("🚀 Starting Roof Analysis API...")
    print("📚 API Documentation: http://localhost:8000/docs")
    print("🔍 Health Check: http://localhost:8000/health")
    
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        reload=True
    )
