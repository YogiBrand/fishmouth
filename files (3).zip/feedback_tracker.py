"""
FEEDBACK TRACKING & CONTINUOUS IMPROVEMENT SYSTEM
Tracks lead outcomes to continuously improve accuracy
"""

import json
from typing import Dict, List, Optional
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
import sqlite3
import os


@dataclass
class LeadOutcome:
    """Track what happened with each lead"""
    analysis_id: str
    property_address: str
    lead_score: float
    lead_priority: str
    
    # Outcome tracking
    contacted: bool = False
    contact_date: Optional[str] = None
    appointment_scheduled: bool = False
    appointment_date: Optional[str] = None
    inspection_completed: bool = False
    inspection_date: Optional[str] = None
    quote_provided: bool = False
    quote_amount: float = 0
    contract_signed: bool = False
    contract_value: float = 0
    contract_date: Optional[str] = None
    
    # Analysis validation
    analysis_accurate: Optional[bool] = None
    actual_roof_age: Optional[int] = None
    actual_damage_severity: Optional[str] = None
    false_positive: bool = False
    false_negative: bool = False
    
    # Notes
    feedback_notes: str = ""
    rejection_reason: str = ""
    
    # Timestamps
    created_at: str = ""
    updated_at: str = ""


class FeedbackTracker:
    """
    Tracks lead outcomes and provides insights for improvement
    """
    
    def __init__(self, db_path: str = "./feedback.db"):
        """Initialize feedback database"""
        self.db_path = db_path
        self._init_database()
    
    def _init_database(self):
        """Create database tables"""
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS lead_outcomes (
                analysis_id TEXT PRIMARY KEY,
                property_address TEXT,
                lead_score REAL,
                lead_priority TEXT,
                
                contacted INTEGER DEFAULT 0,
                contact_date TEXT,
                appointment_scheduled INTEGER DEFAULT 0,
                appointment_date TEXT,
                inspection_completed INTEGER DEFAULT 0,
                inspection_date TEXT,
                quote_provided INTEGER DEFAULT 0,
                quote_amount REAL DEFAULT 0,
                contract_signed INTEGER DEFAULT 0,
                contract_value REAL DEFAULT 0,
                contract_date TEXT,
                
                analysis_accurate INTEGER,
                actual_roof_age INTEGER,
                actual_damage_severity TEXT,
                false_positive INTEGER DEFAULT 0,
                false_negative INTEGER DEFAULT 0,
                
                feedback_notes TEXT,
                rejection_reason TEXT,
                
                created_at TEXT,
                updated_at TEXT
            )
        """)
        
        conn.commit()
        conn.close()
    
    def track_lead(self, analysis_id: str, property_address: str, lead_score: float, lead_priority: str):
        """Start tracking a new lead"""
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        now = datetime.now().isoformat()
        
        cursor.execute("""
            INSERT OR REPLACE INTO lead_outcomes
            (analysis_id, property_address, lead_score, lead_priority, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (analysis_id, property_address, lead_score, lead_priority, now, now))
        
        conn.commit()
        conn.close()
    
    def update_outcome(self, analysis_id: str, **kwargs):
        """Update lead outcome with new information"""
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Build dynamic update query
        set_clause = ", ".join([f"{key} = ?" for key in kwargs.keys()])
        set_clause += ", updated_at = ?"
        
        values = list(kwargs.values()) + [datetime.now().isoformat(), analysis_id]
        
        cursor.execute(f"""
            UPDATE lead_outcomes
            SET {set_clause}
            WHERE analysis_id = ?
        """, values)
        
        conn.commit()
        conn.close()
    
    def get_conversion_metrics(self, days: int = 30) -> Dict:
        """
        Calculate conversion metrics for recent leads
        """
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cutoff_date = (datetime.now() - timedelta(days=days)).isoformat()
        
        # Total leads
        cursor.execute("""
            SELECT COUNT(*) FROM lead_outcomes
            WHERE created_at >= ?
        """, (cutoff_date,))
        total_leads = cursor.fetchone()[0]
        
        # Contacted
        cursor.execute("""
            SELECT COUNT(*) FROM lead_outcomes
            WHERE created_at >= ? AND contacted = 1
        """, (cutoff_date,))
        contacted = cursor.fetchone()[0]
        
        # Appointments
        cursor.execute("""
            SELECT COUNT(*) FROM lead_outcomes
            WHERE created_at >= ? AND appointment_scheduled = 1
        """, (cutoff_date,))
        appointments = cursor.fetchone()[0]
        
        # Inspections
        cursor.execute("""
            SELECT COUNT(*) FROM lead_outcomes
            WHERE created_at >= ? AND inspection_completed = 1
        """, (cutoff_date,))
        inspections = cursor.fetchone()[0]
        
        # Contracts signed
        cursor.execute("""
            SELECT COUNT(*), SUM(contract_value) FROM lead_outcomes
            WHERE created_at >= ? AND contract_signed = 1
        """, (cutoff_date,))
        result = cursor.fetchone()
        contracts = result[0]
        total_revenue = result[1] or 0
        
        # False positives
        cursor.execute("""
            SELECT COUNT(*) FROM lead_outcomes
            WHERE created_at >= ? AND false_positive = 1
        """, (cutoff_date,))
        false_positives = cursor.fetchone()[0]
        
        conn.close()
        
        # Calculate rates
        contact_rate = (contacted / total_leads * 100) if total_leads > 0 else 0
        appointment_rate = (appointments / contacted * 100) if contacted > 0 else 0
        inspection_rate = (inspections / appointments * 100) if appointments > 0 else 0
        close_rate = (contracts / inspections * 100) if inspections > 0 else 0
        overall_conversion = (contracts / total_leads * 100) if total_leads > 0 else 0
        false_positive_rate = (false_positives / total_leads * 100) if total_leads > 0 else 0
        
        return {
            'period_days': days,
            'total_leads': total_leads,
            'contacted': contacted,
            'appointments': appointments,
            'inspections': inspections,
            'contracts': contracts,
            'total_revenue': total_revenue,
            'false_positives': false_positives,
            
            'contact_rate': contact_rate,
            'appointment_rate': appointment_rate,
            'inspection_rate': inspection_rate,
            'close_rate': close_rate,
            'overall_conversion': overall_conversion,
            'false_positive_rate': false_positive_rate,
            
            'avg_contract_value': (total_revenue / contracts) if contracts > 0 else 0
        }
    
    def get_accuracy_metrics(self) -> Dict:
        """
        Calculate analysis accuracy metrics
        """
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Only validated leads
        cursor.execute("""
            SELECT COUNT(*) FROM lead_outcomes
            WHERE analysis_accurate IS NOT NULL
        """)
        validated_count = cursor.fetchone()[0]
        
        # Accurate analyses
        cursor.execute("""
            SELECT COUNT(*) FROM lead_outcomes
            WHERE analysis_accurate = 1
        """)
        accurate_count = cursor.fetchone()[0]
        
        # False positives
        cursor.execute("""
            SELECT COUNT(*) FROM lead_outcomes
            WHERE false_positive = 1
        """)
        false_positive_count = cursor.fetchone()[0]
        
        # False negatives
        cursor.execute("""
            SELECT COUNT(*) FROM lead_outcomes
            WHERE false_negative = 1
        """)
        false_negative_count = cursor.fetchone()[0]
        
        conn.close()
        
        accuracy_rate = (accurate_count / validated_count * 100) if validated_count > 0 else 0
        false_positive_rate = (false_positive_count / validated_count * 100) if validated_count > 0 else 0
        false_negative_rate = (false_negative_count / validated_count * 100) if validated_count > 0 else 0
        
        return {
            'validated_leads': validated_count,
            'accurate_analyses': accurate_count,
            'false_positives': false_positive_count,
            'false_negatives': false_negative_count,
            'accuracy_rate': accuracy_rate,
            'false_positive_rate': false_positive_rate,
            'false_negative_rate': false_negative_rate
        }
    
    def get_lead_quality_by_score(self) -> List[Dict]:
        """
        Analyze conversion rates by lead score ranges
        Helps calibrate scoring thresholds
        """
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        score_ranges = [
            (90, 100, "90-100"),
            (80, 89, "80-89"),
            (70, 79, "70-79"),
            (60, 69, "60-69"),
            (0, 59, "0-59")
        ]
        
        results = []
        
        for min_score, max_score, label in score_ranges:
            cursor.execute("""
                SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN contract_signed = 1 THEN 1 ELSE 0 END) as closed,
                    SUM(CASE WHEN false_positive = 1 THEN 1 ELSE 0 END) as false_pos
                FROM lead_outcomes
                WHERE lead_score >= ? AND lead_score <= ?
            """, (min_score, max_score))
            
            row = cursor.fetchone()
            total = row[0]
            closed = row[1]
            false_pos = row[2]
            
            if total > 0:
                results.append({
                    'score_range': label,
                    'total_leads': total,
                    'closed_deals': closed,
                    'close_rate': (closed / total * 100),
                    'false_positives': false_pos,
                    'false_positive_rate': (false_pos / total * 100)
                })
        
        conn.close()
        
        return results
    
    def get_improvement_insights(self) -> Dict:
        """
        Provide actionable insights for improving the system
        """
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        insights = {
            'recommendations': [],
            'warning_flags': []
        }
        
        # Check overall conversion rate
        metrics = self.get_conversion_metrics(days=30)
        
        if metrics['overall_conversion'] < 10:
            insights['warning_flags'].append("Low overall conversion rate (<10%). Review lead quality thresholds.")
            insights['recommendations'].append("Consider increasing minimum lead score threshold")
        
        if metrics['false_positive_rate'] > 15:
            insights['warning_flags'].append(f"High false positive rate ({metrics['false_positive_rate']:.1f}%). Analysis accuracy needs improvement.")
            insights['recommendations'].append("Review and adjust AI analysis prompt for more conservative damage detection")
        
        if metrics['contact_rate'] < 50:
            insights['warning_flags'].append(f"Low contact rate ({metrics['contact_rate']:.1f}%). Lead delivery or contact info may be issue.")
            insights['recommendations'].append("Verify contact information accuracy and lead delivery timing")
        
        # Check lead score distribution
        score_analysis = self.get_lead_quality_by_score()
        
        # Find best performing score range
        best_range = max(score_analysis, key=lambda x: x['close_rate']) if score_analysis else None
        
        if best_range:
            insights['recommendations'].append(
                f"Focus on leads in {best_range['score_range']} range - {best_range['close_rate']:.1f}% close rate"
            )
        
        # Check for common rejection reasons
        cursor.execute("""
            SELECT rejection_reason, COUNT(*) as count
            FROM lead_outcomes
            WHERE rejection_reason != ''
            GROUP BY rejection_reason
            ORDER BY count DESC
            LIMIT 5
        """)
        
        rejection_reasons = cursor.fetchall()
        if rejection_reasons:
            insights['top_rejection_reasons'] = [
                {'reason': r[0], 'count': r[1]}
                for r in rejection_reasons
            ]
        
        conn.close()
        
        return insights


# Example usage
if __name__ == "__main__":
    # Initialize tracker
    tracker = FeedbackTracker()
    
    # Track a new lead
    tracker.track_lead(
        analysis_id="abc123",
        property_address="123 Main St, Dallas, TX",
        lead_score=85.5,
        lead_priority="QUALIFIED"
    )
    
    # Update as lead progresses
    tracker.update_outcome(
        "abc123",
        contacted=1,
        contact_date=datetime.now().isoformat(),
        appointment_scheduled=1,
        appointment_date=(datetime.now() + timedelta(days=2)).isoformat()
    )
    
    # Later: inspection completed
    tracker.update_outcome(
        "abc123",
        inspection_completed=1,
        inspection_date=datetime.now().isoformat(),
        analysis_accurate=1,  # Analysis was correct
        quote_provided=1,
        quote_amount=15000
    )
    
    # Later: contract signed!
    tracker.update_outcome(
        "abc123",
        contract_signed=1,
        contract_value=14500,
        contract_date=datetime.now().isoformat(),
        feedback_notes="Homeowner very impressed with aerial damage report"
    )
    
    # Get metrics
    print("\n" + "="*60)
    print("CONVERSION METRICS (Last 30 Days)")
    print("="*60)
    
    metrics = tracker.get_conversion_metrics(days=30)
    
    print(f"\nFunnel:")
    print(f"  Total Leads: {metrics['total_leads']}")
    print(f"  Contacted: {metrics['contacted']} ({metrics['contact_rate']:.1f}%)")
    print(f"  Appointments: {metrics['appointments']} ({metrics['appointment_rate']:.1f}%)")
    print(f"  Inspections: {metrics['inspections']} ({metrics['inspection_rate']:.1f}%)")
    print(f"  Contracts: {metrics['contracts']} ({metrics['close_rate']:.1f}%)")
    
    print(f"\nRevenue:")
    print(f"  Total: ${metrics['total_revenue']:,.2f}")
    print(f"  Average Deal: ${metrics['avg_contract_value']:,.2f}")
    
    print(f"\nQuality:")
    print(f"  Overall Conversion: {metrics['overall_conversion']:.1f}%")
    print(f"  False Positive Rate: {metrics['false_positive_rate']:.1f}%")
    
    # Get accuracy metrics
    print("\n" + "="*60)
    print("ACCURACY METRICS")
    print("="*60)
    
    accuracy = tracker.get_accuracy_metrics()
    print(f"\nValidated Leads: {accuracy['validated_leads']}")
    print(f"Accuracy Rate: {accuracy['accuracy_rate']:.1f}%")
    print(f"False Positives: {accuracy['false_positives']} ({accuracy['false_positive_rate']:.1f}%)")
    print(f"False Negatives: {accuracy['false_negatives']} ({accuracy['false_negative_rate']:.1f}%)")
    
    # Get improvement insights
    print("\n" + "="*60)
    print("IMPROVEMENT INSIGHTS")
    print("="*60)
    
    insights = tracker.get_improvement_insights()
    
    if insights['warning_flags']:
        print("\n⚠️  Warning Flags:")
        for flag in insights['warning_flags']:
            print(f"  • {flag}")
    
    if insights['recommendations']:
        print("\n💡 Recommendations:")
        for rec in insights['recommendations']:
            print(f"  • {rec}")
