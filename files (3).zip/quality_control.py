"""
ADVANCED QUALITY CONTROL & LEAD SCORING SYSTEM
Ensures only the highest quality leads are delivered
"""

import cv2
import numpy as np
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
import anthropic
from datetime import datetime
import json


@dataclass
class QualityScore:
    """Quality assessment for images and analysis"""
    overall_score: float  # 0-100
    image_quality: float
    analysis_confidence: float
    data_completeness: float
    consistency_score: float
    issues: List[str]
    pass_threshold: bool


@dataclass
class LeadScore:
    """Comprehensive lead scoring"""
    total_score: float  # 0-100
    priority: str  # QUALIFIED, POTENTIAL, REJECT
    urgency_score: float
    financial_score: float
    damage_score: float
    engagement_score: float
    rejection_reasons: List[str]
    qualification_notes: List[str]


class ImageQualityValidator:
    """
    Pre-flight image quality validation
    Rejects images that won't produce accurate results
    """
    
    # Quality thresholds
    MIN_RESOLUTION = 800  # pixels
    MIN_BRIGHTNESS = 30
    MAX_BRIGHTNESS = 225
    MIN_CONTRAST = 30
    MIN_SHARPNESS = 50
    MAX_BLUR_SCORE = 100
    MIN_ROOF_VISIBILITY = 0.60  # 60% of image should be roof
    
    def __init__(self):
        self.validation_log = []
    
    def validate_image(self, image_data: bytes) -> Tuple[bool, QualityScore]:
        """
        Comprehensive image quality validation
        
        Returns:
            (is_valid, quality_score)
        """
        
        # Decode image
        nparr = np.frombuffer(image_data, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        if img is None:
            return False, QualityScore(
                overall_score=0,
                image_quality=0,
                analysis_confidence=0,
                data_completeness=0,
                consistency_score=0,
                issues=["Failed to decode image"],
                pass_threshold=False
            )
        
        issues = []
        scores = {}
        
        # 1. Resolution check
        height, width = img.shape[:2]
        scores['resolution'] = self._check_resolution(width, height, issues)
        
        # 2. Brightness check
        scores['brightness'] = self._check_brightness(img, issues)
        
        # 3. Contrast check
        scores['contrast'] = self._check_contrast(img, issues)
        
        # 4. Sharpness/blur check
        scores['sharpness'] = self._check_sharpness(img, issues)
        
        # 5. Shadow detection
        scores['shadows'] = self._check_shadows(img, issues)
        
        # 6. Roof visibility check
        scores['roof_visibility'] = self._check_roof_visibility(img, issues)
        
        # 7. Weather interference
        scores['weather'] = self._check_weather_interference(img, issues)
        
        # 8. Compression artifacts
        scores['compression'] = self._check_compression(img, issues)
        
        # Calculate overall score (weighted average)
        weights = {
            'resolution': 0.15,
            'brightness': 0.10,
            'contrast': 0.15,
            'sharpness': 0.20,
            'shadows': 0.10,
            'roof_visibility': 0.20,
            'weather': 0.05,
            'compression': 0.05
        }
        
        overall_score = sum(scores[k] * weights[k] for k in scores)
        
        # Pass threshold: 70+ overall score
        pass_threshold = overall_score >= 70 and len(issues) <= 2
        
        quality_score = QualityScore(
            overall_score=overall_score,
            image_quality=overall_score,
            analysis_confidence=overall_score,
            data_completeness=100,  # Image is complete
            consistency_score=100,  # Single image, no consistency issues
            issues=issues,
            pass_threshold=pass_threshold
        )
        
        return pass_threshold, quality_score
    
    def _check_resolution(self, width: int, height: int, issues: List[str]) -> float:
        """Check image resolution"""
        min_dimension = min(width, height)
        
        if min_dimension < self.MIN_RESOLUTION:
            issues.append(f"Resolution too low: {width}x{height} (need {self.MIN_RESOLUTION}+ pixels)")
            return max(0, (min_dimension / self.MIN_RESOLUTION) * 100)
        
        # Bonus for high resolution
        if min_dimension >= 2000:
            return 100
        elif min_dimension >= 1500:
            return 90
        else:
            return 80
    
    def _check_brightness(self, img: np.ndarray, issues: List[str]) -> float:
        """Check brightness levels"""
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        mean_brightness = np.mean(gray)
        
        if mean_brightness < self.MIN_BRIGHTNESS:
            issues.append(f"Image too dark (brightness: {mean_brightness:.0f})")
            return (mean_brightness / self.MIN_BRIGHTNESS) * 100
        
        if mean_brightness > self.MAX_BRIGHTNESS:
            issues.append(f"Image too bright/washed out (brightness: {mean_brightness:.0f})")
            return (self.MAX_BRIGHTNESS / mean_brightness) * 100
        
        # Optimal range: 80-180
        if 80 <= mean_brightness <= 180:
            return 100
        else:
            return 85
    
    def _check_contrast(self, img: np.ndarray, issues: List[str]) -> float:
        """Check contrast levels"""
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        contrast = gray.std()
        
        if contrast < self.MIN_CONTRAST:
            issues.append(f"Low contrast image (contrast: {contrast:.0f})")
            return (contrast / self.MIN_CONTRAST) * 100
        
        # Higher contrast is generally better for roof analysis
        if contrast >= 60:
            return 100
        elif contrast >= 40:
            return 90
        else:
            return 80
    
    def _check_sharpness(self, img: np.ndarray, issues: List[str]) -> float:
        """Check image sharpness using Laplacian variance"""
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()
        
        if laplacian_var < self.MIN_SHARPNESS:
            issues.append(f"Image too blurry (sharpness: {laplacian_var:.0f})")
            return (laplacian_var / self.MIN_SHARPNESS) * 100
        
        if laplacian_var >= 150:
            return 100
        elif laplacian_var >= 100:
            return 90
        else:
            return 80
    
    def _check_shadows(self, img: np.ndarray, issues: List[str]) -> float:
        """Detect heavy shadows that could hide damage"""
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        # Find very dark areas (potential shadows)
        shadow_mask = gray < 50
        shadow_percentage = (np.sum(shadow_mask) / shadow_mask.size) * 100
        
        if shadow_percentage > 30:
            issues.append(f"Heavy shadows detected ({shadow_percentage:.0f}% of image)")
            return max(0, 100 - (shadow_percentage - 30) * 2)
        
        return 100 - (shadow_percentage * 0.5)  # Small penalty for any shadows
    
    def _check_roof_visibility(self, img: np.ndarray, issues: List[str]) -> float:
        """Estimate what % of image is actually roof (not trees/ground)"""
        
        # Convert to HSV for better color analysis
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        
        # Detect green (trees/grass) - these obscure roof
        lower_green = np.array([35, 40, 40])
        upper_green = np.array([85, 255, 255])
        green_mask = cv2.inRange(hsv, lower_green, upper_green)
        green_percentage = (np.sum(green_mask > 0) / green_mask.size) * 100
        
        # Rough estimate: visible roof = 100% - green% - (edge buffer)
        estimated_roof_visibility = max(0, 100 - green_percentage - 10)
        
        if estimated_roof_visibility < self.MIN_ROOF_VISIBILITY * 100:
            issues.append(f"Low roof visibility (~{estimated_roof_visibility:.0f}% visible, trees/obstructions)")
            return estimated_roof_visibility
        
        return min(100, estimated_roof_visibility)
    
    def _check_weather_interference(self, img: np.ndarray, issues: List[str]) -> float:
        """Detect clouds, fog, rain interference"""
        
        # Convert to grayscale
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        # Check for uniform whitish areas (clouds)
        bright_mask = gray > 200
        bright_percentage = (np.sum(bright_mask) / bright_mask.size) * 100
        
        if bright_percentage > 40:
            issues.append("Possible cloud cover or weather interference")
            return max(50, 100 - bright_percentage)
        
        return 100
    
    def _check_compression(self, img: np.ndarray, issues: List[str]) -> float:
        """Detect heavy JPEG compression artifacts"""
        
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        # Compute frequency domain to detect blocking artifacts
        dft = cv2.dft(np.float32(gray), flags=cv2.DFT_COMPLEX_OUTPUT)
        dft_shift = np.fft.fftshift(dft)
        magnitude = cv2.magnitude(dft_shift[:,:,0], dft_shift[:,:,1])
        
        # High frequency content indicates less compression
        high_freq_energy = np.sum(magnitude[magnitude > np.percentile(magnitude, 95)])
        
        # Normalize (this is heuristic)
        compression_score = min(100, (high_freq_energy / 1e8) * 100)
        
        if compression_score < 50:
            issues.append("Heavy compression artifacts detected")
            return compression_score
        
        return 100


class MultiModelVerification:
    """
    Use multiple AI models to verify findings
    Increases confidence by cross-checking results
    """
    
    def __init__(self, anthropic_api_key: str, openai_api_key: Optional[str] = None):
        self.anthropic_client = anthropic.Anthropic(api_key=anthropic_api_key)
        self.openai_api_key = openai_api_key
    
    def verify_analysis(self, image_base64: str, primary_analysis: Dict) -> Dict:
        """
        Run analysis through multiple models and compare results
        
        Returns:
            {
                'primary_analysis': {...},
                'verification_analysis': {...},
                'agreement_score': 0-100,
                'confidence_level': 'HIGH' | 'MEDIUM' | 'LOW',
                'discrepancies': [...],
                'final_consensus': {...}
            }
        """
        
        # Primary analysis already done with Claude
        primary = primary_analysis
        
        # Verification with GPT-4 Vision (if available)
        verification = None
        if self.openai_api_key:
            verification = self._analyze_with_gpt4(image_base64)
        
        # Compare results
        if verification:
            agreement = self._calculate_agreement(primary, verification)
            discrepancies = self._find_discrepancies(primary, verification)
            consensus = self._build_consensus(primary, verification, agreement)
            
            return {
                'primary_analysis': primary,
                'verification_analysis': verification,
                'agreement_score': agreement,
                'confidence_level': 'HIGH' if agreement >= 85 else 'MEDIUM' if agreement >= 70 else 'LOW',
                'discrepancies': discrepancies,
                'final_consensus': consensus,
                'multi_model_verified': True
            }
        else:
            # Single model only
            return {
                'primary_analysis': primary,
                'verification_analysis': None,
                'agreement_score': primary.get('confidence_overall', 70),
                'confidence_level': 'MEDIUM',  # Single model = medium confidence
                'discrepancies': [],
                'final_consensus': primary,
                'multi_model_verified': False
            }
    
    def _analyze_with_gpt4(self, image_base64: str) -> Dict:
        """Analyze with GPT-4 Vision for verification"""
        # This would call OpenAI's API similar to Claude
        # Placeholder for now
        pass
    
    def _calculate_agreement(self, analysis1: Dict, analysis2: Dict) -> float:
        """Calculate agreement score between two analyses"""
        
        agreements = []
        
        # Compare condition scores (±10 points tolerance)
        score1 = analysis1.get('condition_score', 0)
        score2 = analysis2.get('condition_score', 0)
        score_diff = abs(score1 - score2)
        agreements.append(max(0, 100 - (score_diff * 5)))
        
        # Compare damage counts (should be similar)
        damage1_count = len(analysis1.get('damage_map', []))
        damage2_count = len(analysis2.get('damage_map', []))
        count_diff = abs(damage1_count - damage2_count)
        agreements.append(max(0, 100 - (count_diff * 10)))
        
        # Compare urgency levels
        urgency1 = analysis1.get('replacement_urgency', '')
        urgency2 = analysis2.get('replacement_urgency', '')
        urgency_map = {'IMMEDIATE': 4, 'URGENT': 3, 'PLAN_AHEAD': 2, 'GOOD_CONDITION': 1}
        urgency_diff = abs(urgency_map.get(urgency1, 0) - urgency_map.get(urgency2, 0))
        agreements.append(max(0, 100 - (urgency_diff * 25)))
        
        # Average agreement
        return np.mean(agreements)
    
    def _find_discrepancies(self, analysis1: Dict, analysis2: Dict) -> List[str]:
        """Find major discrepancies between analyses"""
        
        discrepancies = []
        
        # Check condition score difference
        score_diff = abs(analysis1.get('condition_score', 0) - analysis2.get('condition_score', 0))
        if score_diff > 20:
            discrepancies.append(f"Large condition score difference: {score_diff} points")
        
        # Check urgency mismatch
        if analysis1.get('replacement_urgency') != analysis2.get('replacement_urgency'):
            discrepancies.append(f"Urgency mismatch: {analysis1.get('replacement_urgency')} vs {analysis2.get('replacement_urgency')}")
        
        # Check damage count difference
        damage_diff = abs(len(analysis1.get('damage_map', [])) - len(analysis2.get('damage_map', [])))
        if damage_diff > 3:
            discrepancies.append(f"Large damage count difference: {damage_diff} issues")
        
        return discrepancies
    
    def _build_consensus(self, analysis1: Dict, analysis2: Dict, agreement: float) -> Dict:
        """Build consensus analysis from multiple models"""
        
        # If high agreement, use primary
        if agreement >= 85:
            return analysis1
        
        # If medium agreement, average/merge
        consensus = analysis1.copy()
        
        # Average condition scores
        consensus['condition_score'] = int((
            analysis1.get('condition_score', 0) + 
            analysis2.get('condition_score', 0)
        ) / 2)
        
        # Take more conservative (worse) urgency
        urgency_rank = {'GOOD_CONDITION': 1, 'PLAN_AHEAD': 2, 'URGENT': 3, 'IMMEDIATE': 4}
        urgency1 = analysis1.get('replacement_urgency', 'PLAN_AHEAD')
        urgency2 = analysis2.get('replacement_urgency', 'PLAN_AHEAD')
        consensus['replacement_urgency'] = urgency1 if urgency_rank[urgency1] >= urgency_rank[urgency2] else urgency2
        
        # Flag as needs review
        consensus['needs_human_review'] = True
        consensus['review_reason'] = 'Medium agreement between models'
        
        return consensus


class AdvancedLeadScorer:
    """
    Sophisticated lead scoring system
    Only delivers leads with high conversion probability
    """
    
    def __init__(self):
        # Scoring weights (sum to 100)
        self.weights = {
            'urgency': 30,       # How urgent is the roof replacement
            'financial': 25,     # Financial qualification
            'damage_severity': 20,  # How bad is the damage
            'engagement': 15,    # Likelihood of engagement
            'property_value': 10 # Property value indicates budget
        }
        
        # Thresholds
        self.QUALIFIED_THRESHOLD = 75  # 75+ = QUALIFIED lead
        self.POTENTIAL_THRESHOLD = 60  # 60-74 = POTENTIAL lead
        # <60 = REJECT
    
    def score_lead(
        self,
        analysis: Dict,
        property_data: Dict,
        enrichment_data: Optional[Dict] = None
    ) -> LeadScore:
        """
        Comprehensive lead scoring
        
        Args:
            analysis: Roof analysis results
            property_data: Basic property information
            enrichment_data: Optional additional data (property value, income, etc.)
        """
        
        scores = {}
        qualification_notes = []
        rejection_reasons = []
        
        # 1. Urgency Score (30 points)
        scores['urgency'] = self._score_urgency(analysis, qualification_notes, rejection_reasons)
        
        # 2. Financial Score (25 points)
        scores['financial'] = self._score_financial(property_data, enrichment_data, qualification_notes, rejection_reasons)
        
        # 3. Damage Severity Score (20 points)
        scores['damage_severity'] = self._score_damage(analysis, qualification_notes)
        
        # 4. Engagement Score (15 points)
        scores['engagement'] = self._score_engagement(property_data, enrichment_data, qualification_notes)
        
        # 5. Property Value Score (10 points)
        scores['property_value'] = self._score_property(property_data, enrichment_data, qualification_notes)
        
        # Calculate total score
        total_score = sum(scores[k] * (self.weights[k] / 100) for k in scores)
        
        # Determine priority
        if total_score >= self.QUALIFIED_THRESHOLD and len(rejection_reasons) == 0:
            priority = "QUALIFIED"
        elif total_score >= self.POTENTIAL_THRESHOLD and len(rejection_reasons) <= 1:
            priority = "POTENTIAL"
        else:
            priority = "REJECT"
        
        return LeadScore(
            total_score=total_score,
            priority=priority,
            urgency_score=scores['urgency'],
            financial_score=scores['financial'],
            damage_score=scores['damage_severity'],
            engagement_score=scores['engagement'],
            rejection_reasons=rejection_reasons,
            qualification_notes=qualification_notes
        )
    
    def _score_urgency(self, analysis: Dict, notes: List[str], rejections: List[str]) -> float:
        """Score based on replacement urgency"""
        
        urgency = analysis.get('replacement_urgency', 'PLAN_AHEAD')
        condition = analysis.get('condition_score', 50)
        remaining_life = analysis.get('estimated_remaining_life_years', 5)
        
        # Base score from urgency level
        urgency_scores = {
            'IMMEDIATE': 100,
            'URGENT': 80,
            'PLAN_AHEAD': 50,
            'GOOD_CONDITION': 20
        }
        
        score = urgency_scores.get(urgency, 50)
        
        # Adjust based on condition score
        if condition < 40:
            score = min(100, score + 10)
            notes.append(f"Critical condition (score: {condition}/100)")
        elif condition < 60:
            notes.append(f"Poor condition (score: {condition}/100)")
        
        # Adjust based on remaining life
        if remaining_life and remaining_life <= 2:
            score = min(100, score + 10)
            notes.append(f"Urgent: Only {remaining_life} years remaining life")
        
        # Reject if roof is in good condition
        if urgency == 'GOOD_CONDITION' and condition > 75:
            rejections.append("Roof in good condition - not a timely lead")
            score = 0
        
        return score
    
    def _score_financial(self, property_data: Dict, enrichment: Optional[Dict], notes: List[str], rejections: List[str]) -> float:
        """Score financial qualification"""
        
        score = 50  # Default neutral score
        
        if not enrichment:
            notes.append("No financial data available - neutral score")
            return score
        
        # Property value indicates budget
        property_value = enrichment.get('property_value', 0)
        if property_value >= 400000:
            score = 100
            notes.append(f"High property value: ${property_value:,}")
        elif property_value >= 250000:
            score = 80
            notes.append(f"Good property value: ${property_value:,}")
        elif property_value >= 150000:
            score = 60
            notes.append(f"Moderate property value: ${property_value:,}")
        elif property_value > 0:
            score = 40
            notes.append(f"Lower property value: ${property_value:,}")
        
        # Household income (if available)
        household_income = enrichment.get('household_income', 0)
        if household_income >= 100000:
            score = min(100, score + 10)
            notes.append(f"Strong income: ${household_income:,}")
        elif household_income >= 75000:
            notes.append(f"Good income: ${household_income:,}")
        elif household_income > 0 and household_income < 50000:
            score = max(0, score - 20)
            rejections.append(f"Low income may affect qualification: ${household_income:,}")
        
        # Recent foreclosure/bankruptcy (automatic reject)
        if enrichment.get('foreclosure_risk', False):
            rejections.append("Foreclosure risk flagged")
            score = 0
        
        # Homeowner vs renter
        if enrichment.get('owner_occupied', False):
            notes.append("Owner-occupied (qualified)")
        else:
            rejections.append("Not owner-occupied - likely renter")
            score = 0
        
        return score
    
    def _score_damage(self, analysis: Dict, notes: List[str]) -> float:
        """Score based on damage severity"""
        
        damage_map = analysis.get('damage_map', [])
        damage_summary = analysis.get('damage_summary', {})
        
        # Count critical/urgent issues
        critical_count = sum(1 for d in damage_map if d.get('severity') == 'CRITICAL')
        urgent_count = sum(1 for d in damage_map if d.get('severity') == 'URGENT')
        
        score = 0
        
        # Critical issues = high score (urgent need)
        if critical_count >= 2:
            score = 100
            notes.append(f"{critical_count} CRITICAL issues found")
        elif critical_count == 1:
            score = 90
            notes.append("1 CRITICAL issue found")
        elif urgent_count >= 3:
            score = 80
            notes.append(f"{urgent_count} URGENT issues found")
        elif urgent_count >= 1:
            score = 70
            notes.append(f"{urgent_count} URGENT issues found")
        elif len(damage_map) >= 3:
            score = 60
            notes.append(f"{len(damage_map)} total issues found")
        else:
            score = 40
        
        # Check specific damage types that drive sales
        if damage_summary.get('missing_shingles_pct', 0) > 10:
            score = min(100, score + 10)
            notes.append(f"Significant missing shingles: {damage_summary['missing_shingles_pct']:.0f}%")
        
        if damage_summary.get('structural_damage_pct', 0) > 5:
            score = min(100, score + 15)
            notes.append("Structural damage detected - high urgency")
        
        return score
    
    def _score_engagement(self, property_data: Dict, enrichment: Optional[Dict], notes: List[str]) -> float:
        """Score likelihood of engagement"""
        
        score = 50  # Default
        
        # Roof age (sweet spot: 15-25 years)
        roof_age = property_data.get('roof_age_years', 0)
        if 15 <= roof_age <= 25:
            score = 90
            notes.append(f"Prime age for replacement: {roof_age} years")
        elif 12 <= roof_age <= 30:
            score = 70
            notes.append(f"Good age for replacement: {roof_age} years")
        elif roof_age > 30:
            score = 95
            notes.append(f"Overdue for replacement: {roof_age} years")
        elif roof_age < 10:
            score = 20
            notes.append(f"Recently installed: {roof_age} years")
        
        if enrichment:
            # Recent insurance claim = higher engagement
            if enrichment.get('recent_insurance_claim', False):
                score = min(100, score + 20)
                notes.append("Recent insurance claim - highly engaged")
            
            # Homeowner tenure (longer = more likely to invest)
            tenure = enrichment.get('years_at_address', 0)
            if tenure >= 10:
                score = min(100, score + 10)
                notes.append(f"Long-term resident: {tenure} years")
            elif tenure < 2:
                score = max(0, score - 15)
                notes.append(f"Recent move-in: {tenure} years - may delay")
        
        return score
    
    def _score_property(self, property_data: Dict, enrichment: Optional[Dict], notes: List[str]) -> float:
        """Score based on property characteristics"""
        
        score = 50  # Default
        
        # Property type (single family = best)
        prop_type = property_data.get('property_type', '').lower()
        if 'single family' in prop_type or 'detached' in prop_type:
            score = 90
            notes.append("Single-family home (ideal)")
        elif 'condo' in prop_type or 'townhouse' in prop_type:
            score = 60
            notes.append("Condo/townhouse (HOA may complicate)")
        
        # Size (larger = higher project value)
        sq_ft = property_data.get('square_footage', 0)
        if sq_ft >= 3000:
            score = 100
            notes.append(f"Large home: {sq_ft:,} sq ft")
        elif sq_ft >= 2000:
            score = 85
        elif sq_ft >= 1500:
            score = 70
        elif sq_ft > 0:
            score = 60
        
        if enrichment:
            # Neighborhood quality
            neighborhood_score = enrichment.get('neighborhood_quality', 50)
            if neighborhood_score >= 80:
                notes.append("High-quality neighborhood")
                score = min(100, score + 10)
        
        return score


# Example usage
if __name__ == "__main__":
    # Test image quality validation
    validator = ImageQualityValidator()
    
    with open("test_roof.jpg", "rb") as f:
        image_data = f.read()
    
    is_valid, quality_score = validator.validate_image(image_data)
    
    print(f"\nImage Quality Validation:")
    print(f"  Valid: {is_valid}")
    print(f"  Overall Score: {quality_score.overall_score:.1f}/100")
    print(f"  Issues: {len(quality_score.issues)}")
    for issue in quality_score.issues:
        print(f"    - {issue}")
    
    # Test lead scoring
    scorer = AdvancedLeadScorer()
    
    sample_analysis = {
        'condition_score': 45,
        'replacement_urgency': 'URGENT',
        'estimated_remaining_life_years': 2,
        'damage_map': [
            {'severity': 'CRITICAL'},
            {'severity': 'URGENT'},
            {'severity': 'URGENT'}
        ],
        'damage_summary': {
            'missing_shingles_pct': 15,
            'structural_damage_pct': 8
        }
    }
    
    sample_property = {
        'roof_age_years': 19,
        'property_type': 'Single Family',
        'square_footage': 2400
    }
    
    sample_enrichment = {
        'property_value': 450000,
        'household_income': 125000,
        'owner_occupied': True,
        'years_at_address': 12,
        'recent_insurance_claim': True
    }
    
    lead_score = scorer.score_lead(sample_analysis, sample_property, sample_enrichment)
    
    print(f"\nLead Scoring:")
    print(f"  Total Score: {lead_score.total_score:.1f}/100")
    print(f"  Priority: {lead_score.priority}")
    print(f"  Urgency: {lead_score.urgency_score:.1f}")
    print(f"  Financial: {lead_score.financial_score:.1f}")
    print(f"  Damage: {lead_score.damage_score:.1f}")
    print(f"  Engagement: {lead_score.engagement_score:.1f}")
    print(f"\nQualification Notes:")
    for note in lead_score.qualification_notes:
        print(f"  ✓ {note}")
    
    if lead_score.rejection_reasons:
        print(f"\nRejection Reasons:")
        for reason in lead_score.rejection_reasons:
            print(f"  ✗ {reason}")
